<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Bootgly and contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ACI\Process;


use const BOOTGLY_STORAGE_DIR;
use const LOCK_EX;
use const LOCK_NB;
use const LOCK_SH;
use const LOCK_UN;
use function bin2hex;
use function chmod;
use function closedir;
use function ctype_digit;
use function decoct;
use function fclose;
use function fflush;
use function file_exists;
use function file_get_contents;
use function filemtime;
use function flock;
use function fopen;
use function fstat;
use function fsync;
use function ftruncate;
use function function_exists;
use function fwrite;
use function is_array;
use function is_dir;
use function is_file;
use function is_link;
use function is_resource;
use function is_string;
use function json_decode;
use function json_encode;
use function lchgrp;
use function lchown;
use function lstat;
use function mkdir;
use function opendir;
use function posix_geteuid;
use function posix_getpid;
use function preg_match;
use function random_bytes;
use function readdir;
use function rename;
use function rewind;
use function rewinddir;
use function rtrim;
use function stat;
use function str_ends_with;
use function str_starts_with;
use function stream_get_contents;
use function strlen;
use function strrpos;
use function substr;
use function time;
use function umask;
use function unlink;
use RuntimeException;
use WeakReference;


class State
{
   // * Config
   /**
    * Age (seconds) past which an unheld state inode is treated as abandoned
    * by `sweep()`. Must comfortably exceed the window between creating a lock
    * file and acquiring its lock, so a process still starting is never swept.
    */
   public const int ORPHAN_TTL = 300;
   // ...

   // * Data
   private string $id;
   public string $pidFile;
   public string $pidLockFile;
   public string $commandFile;
   /** Per-instance live-log tap socket pathname (bound by WPI server masters). */
   public string $tapFile;

   // * Metadata
   private string $pidsDir;
   /** @var resource|null */
   private mixed $lockHandle = null;
   /** The local handle represents an acquired instance lock. */
   private bool $locked = false;
   /** PID that acquired or adopted the local lock descriptor. */
   private null|int $ownerPID = null;
   /**
    * The instance locks this process acquired or adopted, by lock file: the
    * State holding each one. A forked child inherits the map, never the
    * claim — `$held` checks the holder's PID and its live descriptor.
    *
    * @var array<string,WeakReference<State>>
    */
   private static array $holders = [];
   /**
    * This process holds this instance's lock — through this State or any
    * other over the same lock file: a live holder, owned by this PID, whose
    * descriptor is still the inode at the lock path. It proves a
    * same-process holder without procfs (Darwin has none); a foreign holder
    * is `authenticate()`'s.
    */
   public bool $held {
      get {
         $Holder = (self::$holders[$this->pidLockFile] ?? null)?->get();

         // :
         return $Holder !== null
            && $Holder->locked
            && $Holder->ownerPID === posix_getpid()
            && $Holder->pidLockFile === $this->pidLockFile
            && $Holder->lockHandle !== null
            && $Holder->verify($Holder->lockHandle);
      }
   }


   public function __construct (string $id, null|string $instance = null)
   {
      $this->pidsDir = BOOTGLY_STORAGE_DIR . 'pids/';

      if (is_dir($this->pidsDir) === false) {
         @mkdir($this->pidsDir, 0755, true);
      }
      // ! Upgrade repair: an older release delegated the shared directory to
      //   the configured runtime UID. A privileged launch reclaims that exact
      //   inode for the trusted storage administrator before any per-instance
      //   pathname is opened; otherwise the old owner could still replace
      //   another service's lock/state during boot.
      $refusal = $this->protect();
      if ($refusal !== null) {
         throw new RuntimeException("Unsafe process state directory at {$this->pidsDir}: {$refusal}");
      }

      // @ Extract short class name from FQCN (e.g. Bootgly\WPI\Nodes\HTTP_Server_CLI → HTTP_Server_CLI)
      $pos = strrpos($id, '\\');
      if ($pos !== false) {
         $id = substr($id, $pos + 1);
      }

      $this->id = $id;

      $this->qualify($instance);
   }

   /**
    * Qualify the state file names with an instance qualifier.
    * Rebuilds the PID, lock and command file paths from the base id
    * (e.g. instance `8080` → `<id>.8080.json`). Servers call this once the
    * bound port is known — before any lock or save.
    *
    * @param null|string $instance The instance qualifier (null = unqualified).
    *
    * @return void
    */
   public function qualify (null|string $instance): void
   {
      $id = $this->id;

      // @ Append instance qualifier (e.g. HTTP_Server_CLI.8080)
      if ($instance !== null) {
         $id .= ".$instance";
      }

      $this->pidFile     = "{$this->pidsDir}$id.json";
      $this->pidLockFile = "{$this->pidsDir}$id.lock";
      $this->commandFile = "{$this->pidsDir}$id.command";
      $this->tapFile     = "{$this->pidsDir}$id.logs.sock";
   }

   /**
    * Lock the process to prevent multiple instances.
    *
    * @param int<0,7> $flag The lock flag (default: LOCK_EX).
    *
    * @return bool false when the lock is held by another process (LOCK_NB).
    */
   public function lock (int $flag = LOCK_EX): bool
   {
      $file = $this->pidLockFile;
      $currentPID = posix_getpid();

      if ($flag === LOCK_UN) {
         if ($this->lockHandle === null) {
            $this->locked = false;
            $this->ownerPID = null;
            return true;
         }
         // ! A worker inherits the master's open-file-description. It may
         //   close its duplicate through detach(), but must never unlock the
         //   shared kernel lock or claim cleanup authority from that handle.
         if ($this->ownerPID !== $currentPID) {
            return false;
         }
         flock($this->lockHandle, LOCK_UN);
         fclose($this->lockHandle);
         $this->lockHandle = null;
         $this->locked = false;
         $this->ownerPID = null;
         // ? The claim goes with this descriptor
         if ((self::$holders[$file] ?? null)?->get() === $this) {
            unset(self::$holders[$file]);
         }

         return true;
      }

      if ($this->lockHandle !== null && $this->ownerPID !== $currentPID) {
         return false;
      }

      $this->lockHandle = $this->lockHandle ?: $this->open($file);

      // ! Lock file unavailable/unsafe: fail closed. Proceeding unguarded
      //   would permit two SO_REUSEPORT masters for one instance identity.
      if ($this->lockHandle === null) {
         return false;
      }

      // ! `open()` applies its mask only when it CREATES the inode, so a lock
      //   restored from a backup, pre-created by a deploy or left behind by
      //   another UID arrives with whatever mode it had. `authenticate()`
      //   demands exactly 0600, so serving on such an inode would publish an
      //   instance no control command could ever verify — it would start,
      //   bind and answer while `stop`/`show`/`reload` all report it absent.
      //   Repair it here; fail closed when the repair is impossible.
      if ($this->seal($this->lockHandle) === false) {
         fclose($this->lockHandle);

         $this->lockHandle = null;
         $this->locked = false;
         $this->ownerPID = null;

         return false;
      }

      $locked = flock($this->lockHandle, $flag);

      // ? Lock held by another process (LOCK_NB): release the handle
      if ($locked === false) {
         fclose($this->lockHandle);

         $this->lockHandle = null;
         $this->ownerPID = null;
      }
      // Only the exclusive instance lock is eligible for exec handoff; a
      // shared/read lock must never be promoted into serving authority.
      $this->locked = $locked && ($flag & LOCK_EX) === LOCK_EX;
      $this->ownerPID = $locked ? $currentPID : null;
      // @ Claim the instance lock for this process
      if ($this->locked) {
         self::$holders[$file] = WeakReference::create($this);
      }

      // :
      return $locked;
   }

   /**
    * Close only this process's inherited lock descriptor.
    *
    * Long-running forked auxiliaries that do not represent the serving process
    * must not retain the master instance lock. They also must not call LOCK_UN:
    * flock state is shared by the inherited open-file description and an
    * explicit unlock would release the master's lock too. Workers deliberately
    * retain their descriptor until their parent watchdog stops them.
    */
   public function detach (): void
   {
      if ($this->lockHandle !== null) {
         fclose($this->lockHandle);
         $this->lockHandle = null;
      }
      // ? The holder's own descriptor is gone: so is its claim
      if ((self::$holders[$this->pidLockFile] ?? null)?->get() === $this) {
         unset(self::$holders[$this->pidLockFile]);
      }
      $this->locked = false;
      $this->ownerPID = null;
   }

   /**
    * Return the exact acquired lock descriptor for an internal exec handoff.
    *
    * The caller must transfer this descriptor without closing or unlocking the
    * final live duplicate. Returning null fails closed if qualification changed,
    * the pathname was replaced, or this State never acquired the lock.
    *
    * @return resource|null
    */
   public function export (): mixed
   {
      if (
         $this->locked === false
         || $this->lockHandle === null
         || $this->ownerPID !== posix_getpid()
         || $this->verify($this->lockHandle) === false
      ) {
         return null;
      }

      return $this->lockHandle;
   }

   /**
    * Adopt a transferred lock descriptor for the already-qualified instance.
    *
    * SCM_RIGHTS preserves the sender's open-file description, and therefore
    * its flock. The non-blocking flock below is also an atomic fail-closed
    * check: a descriptor that did not carry the lock can only be adopted if no
    * competing master acquired the exact stable inode first.
    *
    * @param resource $Handle
    */
   public function adopt (mixed $Handle): bool
   {
      if (
         $this->lockHandle !== null
         || is_resource($Handle) === false
         || $this->verify($Handle) === false
         || flock($Handle, LOCK_EX | LOCK_NB) === false
      ) {
         return false;
      }
      // @phpstan-ignore identical.alwaysFalse (intentional post-flock pathname race recheck)
      if ($this->verify($Handle) === false) {
         return false;
      }

      $this->lockHandle = $Handle;
      $this->locked = true;
      $this->ownerPID = posix_getpid();
      self::$holders[$this->pidLockFile] = WeakReference::create($this);

      return true;
   }

   /**
    * Save process state data to the PID file.
    *
    * @param array<string,mixed> $data
    *
    * @return void
    */
   public function save (array $data): void
   {
      $JSON = json_encode($data);
      if ($JSON === false || is_link($this->pidFile)) {
         throw new RuntimeException('Can not save process state to ' . $this->pidFile);
      }

      $temporary = $this->pidFile . '.' . bin2hex(random_bytes(8)) . '.tmp';
      $previousMask = umask(0022);
      try {
         $Handle = @fopen($temporary, 'x+b');
      }
      finally {
         umask($previousMask);
      }
      if ($Handle === false) {
         if ($this->rewrite($this->pidFile, $JSON)) {
            return;
         }
         throw new RuntimeException('Can not safely update process state at ' . $this->pidFile);
      }

      $written = false;
      try {
         $length = strlen($JSON);
         $offset = 0;
         while ($offset < $length) {
            $bytes = fwrite($Handle, substr($JSON, $offset));
            if ($bytes === false || $bytes === 0) {
               break;
            }
            $offset += $bytes;
         }
         $written = $offset === $length
            && fflush($Handle)
            && (!function_exists('fsync') || fsync($Handle));
      }
      finally {
         fclose($Handle);
         if ($written === false) {
            @unlink($temporary);
         }
      }

      if ($written === false || rename($temporary, $this->pidFile) === false) {
         @unlink($temporary);
         if ($written && $this->rewrite($this->pidFile, $JSON)) {
            return;
         }
         throw new RuntimeException('Can not commit process state to ' . $this->pidFile);
      }
   }

   /**
    * Read process state data from the PID file.
    *
    * @return array<string,mixed>|null
    */
   public function read (): null|array
   {
      if (is_link($this->pidFile) || is_file($this->pidFile) === false) {
         return null;
      }

      $before = @lstat($this->pidFile);
      $Handle = @fopen($this->pidFile, 'rb');
      if ($Handle === false || flock($Handle, LOCK_SH) === false) {
         is_resource($Handle) && fclose($Handle);
         return null;
      }

      try {
         $opened = fstat($Handle);
         $after = @lstat($this->pidFile);
         if (
            is_array($before) === false || is_array($opened) === false || is_array($after) === false
            || $before['dev'] !== $opened['dev']
            || $before['ino'] !== $opened['ino']
            || $after['dev'] !== $opened['dev']
            || $after['ino'] !== $opened['ino']
         ) {
            return null;
         }
         $contents = stream_get_contents($Handle, 65537);
      }
      finally {
         flock($Handle, LOCK_UN);
         fclose($Handle);
      }

      if (is_string($contents) === false || strlen($contents) > 65536) {
         return null;
      }

      $data = json_decode($contents, true);
      if (is_array($data) === false) {
         return null;
      }
      foreach ($data as $key => $_) {
         if (is_string($key) === false) {
            return null;
         }
      }
      /** @var array<string,mixed> $data */

      return $data;
   }

   /**
    * Check whether the PID file contains valid process state.
    *
    * @return bool
    */
   public function check (): bool
   {
      // ? A clean state intentionally keeps the per-instance inode in place:
      //   a demoted process may own the file but cannot unlink it from the
      //   protected, storage-admin-owned `pids/` directory. Empty/invalid
      //   content is the tombstone, so pathname existence alone must never
      //   advertise a live process.
      return $this->read() !== null;
   }

   /**
    * Authenticate a process against this exact qualified instance lock.
    *
    * The PID document is deliberately runtime-writable and is discovery data,
    * never an identity authority. A serving master and its forked workers keep
    * the acquired lock's open-file-description for their complete lifetime.
    * Linux exposes that kernel-held relationship through `/proc/<pid>/fd` and
    * `fdinfo`; an unrelated or PID-reused process cannot satisfy it merely by
    * copying fields into the mutable JSON document.
    *
    * When the kernel hides those two directories — every Bootgly server is
    * non-dumpable once the documented `setcap cap_net_bind_service=+ep` is
    * applied to the PHP binary — the proof falls back to `confirm()`, which
    * reads the same bookkeeping from the system-wide `/proc/locks` table.
    *
    * @param int $PID Process to authenticate.
    * @param null|int $parent Required direct parent PID for worker checks.
    */
   public function authenticate (
      int $PID,
      null|int $parent = null
   ): bool
   {
      if (
         $PID <= 0
         || ($parent !== null && $parent <= 0)
         || is_link($this->pidLockFile)
      ) {
         return false;
      }

      $before = @lstat($this->pidLockFile);
      if (
         is_array($before) === false
         || ((int) $before['mode'] & 0170000) !== 0100000
         || ((int) $before['mode'] & 0777) !== 0600
      ) {
         return false;
      }

      $status = @file_get_contents("/proc/{$PID}/status");
      if (
         is_string($status) === false
         || preg_match(
            '/^Uid:\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*$/m',
            $status,
            $UIDs,
         ) !== 1
         || (int) $UIDs[1] !== (int) $UIDs[2]
         || (int) $UIDs[2] !== (int) $UIDs[3]
         || (int) $UIDs[3] !== (int) $UIDs[4]
      ) {
         return false;
      }
      if ($parent === null) {
         if ((int) $UIDs[1] !== (int) $before['uid']) {
            return false;
         }
      }
      else {
         $parentStatus = @file_get_contents("/proc/{$parent}/status");
         if (
            preg_match('/^PPid:\s+(\d+)\s*$/m', $status, $parents) !== 1
            || (int) $parents[1] !== $parent
            || is_string($parentStatus) === false
            || preg_match(
               '/^Uid:\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*$/m',
               $parentStatus,
               $parentUIDs,
            ) !== 1
            || (int) $parentUIDs[1] !== (int) $before['uid']
            || (int) $parentUIDs[2] !== (int) $before['uid']
            || (int) $parentUIDs[3] !== (int) $before['uid']
            || (int) $parentUIDs[4] !== (int) $before['uid']
         ) {
            return false;
         }
      }

      $bound = false;

      // ---

      // @ Per-descriptor evidence: the strongest proof, because it shows THIS
      //   process holds the locked open-file-description.
      $Directory = @opendir("/proc/{$PID}/fd");

      // ? Gaining privileges at exec marks a process non-dumpable, so the
      //   kernel hands its `fd/` and `fdinfo/` to root and even its own owner
      //   cannot enumerate them. Bootgly documents
      //   `setcap cap_net_bind_service=+ep` on the PHP binary to bind :80/:443
      //   without root, which puts every server on that path.
      if ($Directory === false) {
         $bound = $this->confirm($parent ?? $PID, (int) $before['ino']);
      }
      else {
         $inspected = 0;
         try {
            while (($descriptor = readdir($Directory)) !== false) {
               if (ctype_digit($descriptor) === false) {
                  continue;
               }
               if (++$inspected > 65536) {
                  break;
               }

               $FD = "/proc/{$PID}/fd/{$descriptor}";
               $opened = @stat($FD);
               if (
                  is_array($opened) === false
                  || $opened['dev'] !== $before['dev']
                  || $opened['ino'] !== $before['ino']
                  || ((int) $opened['mode'] & 0170000) !== 0100000
               ) {
                  continue;
               }

               $info = @file_get_contents("/proc/{$PID}/fdinfo/{$descriptor}");
               $confirmed = @stat($FD);
               if (
                  is_string($info)
                  && preg_match(
                     '/^lock:\s+\d+:\s+FLOCK\s+ADVISORY\s+WRITE\s+(\d+)\s+[0-9a-f]+:[0-9a-f]+:'
                        . (string) $before['ino'] . '\s+0\s+EOF\s*$/mi',
                     $info,
                     $locks,
                  ) === 1
                  && (int) $locks[1] === ($parent ?? $PID)
                  // @phpstan-ignore function.alreadyNarrowedType (stat()/lstat() are never cached; PHPStan 2.3 remembers them until clearstatcache())
                  && is_array($confirmed)
                  && $confirmed['dev'] === $before['dev']
                  && $confirmed['ino'] === $before['ino']
               ) {
                  $bound = true;
                  break;
               }
            }
         }
         finally {
            closedir($Directory);
         }
      }

      $after = @lstat($this->pidLockFile);

      return $bound
         // @phpstan-ignore function.alreadyNarrowedType (stat()/lstat() are never cached; PHPStan 2.3 remembers them until clearstatcache())
         && is_array($after)
         && $after['dev'] === $before['dev']
         && $after['ino'] === $before['ino']
         && ((int) $after['mode'] & 0170000) === 0100000
         && ((int) $after['mode'] & 0777) === 0600
         && $after['uid'] === $before['uid'];
   }

   /**
    * Confirm through the kernel's system-wide lock table that a PID holds the
    * exclusive `flock` covering an inode.
    *
    * This is the fallback for `authenticate()` when `/proc/<pid>/fd` is
    * unreadable. `/proc/locks` publishes the same kernel bookkeeping as
    * `fdinfo` without the dumpability restriction, so a non-dumpable server
    * stays verifiable — and therefore stoppable — by its own owner.
    *
    * It proves the lock exists and names its holder, but cannot prove the
    * inspected PID inherited the descriptor. Workers are consequently only ever
    * accepted alongside the caller's `PPid`/UID checks, which already bind them
    * to the very master named here.
    *
    * The device columns are deliberately not compared: filesystems such as
    * btrfs report anonymous devices that never match `stat()`, which is why the
    * per-descriptor path re-verifies identity through `stat()` instead.
    *
    * @param int $holder PID that must hold the lock.
    * @param int $inode Inode the lock must cover.
    */
   private function confirm (int $holder, int $inode): bool
   {
      $locks = @file_get_contents('/proc/locks');
      if (is_string($locks) === false) {
         return false;
      }

      // : Blocked waiters are printed as `<id>: -> FLOCK ...`, so requiring
      //   `FLOCK` immediately after the entry id never counts a pending lock.
      return preg_match(
         '/^\d+:\s+FLOCK\s+ADVISORY\s+WRITE\s+' . $holder
            . '\s+[0-9a-f]+:[0-9a-f]+:' . $inode . '\s+0\s+EOF\s*$/mi',
         $locks,
      ) === 1;
   }

   /**
    * Transfer ownership of this instance's state files to the given user/group.
    * Must be called while the process still has privileges (e.g. root)
    * before demoting, so the demoted user can later rewrite/tombstone them.
    *
    * The shared `pids/` directory deliberately belongs to the trusted storage
    * administrator. Handing it to one runtime UID would let that identity
    * replace or remove every other service's state and lock pathnames. clean()
    * therefore clears owned PID/command inodes in place instead of requiring
    * directory writes.
    *
    * @param int $UID
    * @param int $GID
    *
    * @return bool Whether every existing regular state file was handed off.
    */
   public function own (int $UID, int $GID): bool
   {
      // ? Re-run immediately before handoff as a final identity/mode check and
      //   to repair a legacy runtime-owned directory on an upgraded root boot.
      if ($this->protect() !== null) {
         return false;
      }
      $pids = rtrim($this->pidsDir, '/');
      $directory = @lstat($pids);
      if (
         is_array($directory) === false
         || ((int) $directory['mode'] & 0170000) !== 0040000
      ) {
         return false;
      }

      foreach ([$this->pidFile, $this->pidLockFile, $this->commandFile] as $file) {
         $before = @lstat($file);
         // ? A state file may not exist yet (workers can demote before the
         //   final master publishes its PID document). The master performs its
         //   own handoff after save(), so absence here is valid.
         if ($before === false) {
            continue;
         }
         if (
            ((int) $before['mode'] & 0170000) !== 0100000
            || @lchown($file, $UID) === false
            || @lchgrp($file, $GID) === false
         ) {
            return false;
         }
         $after = @lstat($file);
         if (
            // @phpstan-ignore function.alreadyNarrowedType, identical.alwaysFalse (stat()/lstat() are never cached; PHPStan 2.3 remembers them until clearstatcache())
            is_array($after) === false
            || $before['dev'] !== $after['dev']
            || $before['ino'] !== $after['ino']
            || ((int) $after['mode'] & 0170000) !== 0100000
            || (int) $after['uid'] !== $UID
            || (int) $after['gid'] !== $GID
         ) {
            return false;
         }
      }

      $after = @lstat($pids);

      // ! The directory itself must remain the exact same inode, owner and
      //   group throughout the handoff. Only the per-instance regular files
      //   are delegated to the runtime identity.
      // @phpstan-ignore function.alreadyNarrowedType (stat()/lstat() are never cached; PHPStan 2.3 remembers them until clearstatcache())
      return is_array($after)
         && $directory['dev'] === $after['dev']
         && $directory['ino'] === $after['ino']
         && $directory['uid'] === $after['uid']
         && $directory['gid'] === $after['gid']
         && ((int) $after['mode'] & 0170000) === 0040000;
   }

   /**
    * Clean the replaceable per-project state (PID and command).
    *
    * The lock inode deliberately remains in place. Unlinking a flock file after
    * unlock lets a concurrent opener retain the old inode while a third process
    * creates and locks a new inode under the same path, defeating exclusivity.
    * PID and command inodes normally remain too: after privilege demotion their
    * owner can truncate them, but cannot safely receive write permission on the
    * shared parent directory merely to unlink them. The trusted storage admin
    * may remove a foreign-owned state inode after a hard kill. An empty PID file
    * is a tombstone; check()/read() therefore report it as absent.
    *
    * Only the PID that acquired or adopted the exact exclusive lock may clean
    * state. Forked workers inherit the descriptor, but not cleanup authority.
    *
    * @return bool true when state was cleaned and the lock was released.
    */
   /**
    * Reclaim state inodes that no live process still holds.
    *
    * `clean()` tombstones the PID/command inodes but never removes the lock:
    * a demoted runtime UID owns the file yet cannot unlink from the shared
    * directory. Every distinct instance qualifier therefore leaves one lock
    * behind forever — one per client PID, one per server port — and nothing
    * ever reclaimed them. Left unbounded the directory reached 1,879 entries
    * here, which pushed new listener descriptors past `FD_SETSIZE`; there
    * `stream_select()` fails, the listener admission probe refuses, and the
    * server will not start at all.
    *
    * Liveness is decided by a non-blocking exclusive `flock`, never by parsing
    * the qualifier: that qualifier is as often a port as a PID, and the lock
    * is the only authority on whether an owner is still running. An entry
    * whose lock is free and whose mtime is older than `$minAge` is gone.
    *
    * @param int $minAge Seconds an entry must be untouched before it is swept.
    *
    * @return int Number of reclaimed entries.
    */
   public function sweep (int $minAge = self::ORPHAN_TTL): int
   {
      // ? The same contract `tombstone()` enforces: a real, contained,
      //   non-symlinked directory this process administers.
      $pids = rtrim($this->pidsDir, '/');
      $directory = @lstat($pids);
      if (
         is_link($pids)
         || is_array($directory) === false
         || ((int) $directory['mode'] & 0170000) !== 0040000
         || (int) $directory['uid'] !== posix_geteuid()
         || ((int) $directory['mode'] & 0022) !== 0
      ) {
         return 0;
      }

      $handle = @opendir($this->pidsDir);
      if ($handle === false) {
         return 0;
      }

      // !
      $cutoff = time() - $minAge;
      $swept = 0;

      // @@
      while (($entry = readdir($handle)) !== false) {
         // ? `.`/`..` and any dotfile placeholder
         if ($entry[0] === '.' || str_ends_with($entry, '.lock') === false) {
            continue;
         }

         $lock = $this->pidsDir . $entry;

         // ? Never our own instance, and never a symlink
         if ($lock === $this->pidLockFile || is_link($lock) || is_file($lock) === false) {
            continue;
         }
         if ((int) @filemtime($lock) > $cutoff) {
            continue;
         }

         $probe = @fopen($lock, 'r+b');
         if ($probe === false) {
            continue;
         }

         // ? A live owner still holds it — leave everything alone.
         $free = @flock($probe, LOCK_EX | LOCK_NB);
         if ($free) {
            @flock($probe, LOCK_UN);
         }
         @fclose($probe);

         if ($free === false) {
            continue;
         }

         // @ One instance owns five inodes: the lock, its PID and command
         //   files, the downloads counter and the live-log tap socket keyed
         //   to the same identity.
         $id = substr($entry, 0, -5);
         @unlink($lock);
         @unlink("{$this->pidsDir}{$id}.json");
         @unlink("{$this->pidsDir}{$id}.command");
         @unlink("{$this->pidsDir}{$id}.lock.downloads");
         @unlink("{$this->pidsDir}{$id}.logs.sock");
         $swept++;
      }

      rewinddir($handle);

      // @@ A previous sweep (or an administrator) may have removed the lock
      //    while leaving its siblings behind. Without this they would never be
      //    reclaimed, because the pass above is keyed on the lock.
      while (($entry = readdir($handle)) !== false) {
         if ($entry[0] === '.') {
            continue;
         }

         $suffix = strrpos($entry, '.');
         if ($suffix === false) {
            continue;
         }

         $extension = substr($entry, $suffix + 1);
         if (
            $extension !== 'json' && $extension !== 'command'
            && $extension !== 'downloads' && $extension !== 'sock'
         ) {
            continue;
         }

         $id = match ($extension) {
            'downloads' => substr($entry, 0, -15),
            'sock'      => substr($entry, 0, -10),
            default     => substr($entry, 0, $suffix)
         };
         if ($id === '' || is_file("{$this->pidsDir}{$id}.lock")) {
            continue;
         }

         $file = $this->pidsDir . $entry;
         if (
            is_link($file)
            // ? A tap socket is not a regular file — probe it by existence
            || ($extension === 'sock' ? file_exists($file) === false : is_file($file) === false)
            || (int) @filemtime($file) > $cutoff
         ) {
            continue;
         }

         @unlink($file);
         $swept++;
      }

      closedir($handle);

      // :
      return $swept;
   }

   public function clean (): bool
   {
      if (
         $this->locked === false
         || $this->lockHandle === null
         || $this->ownerPID !== posix_getpid()
         || $this->verify($this->lockHandle) === false
      ) {
         return false;
      }

      $command = $this->tombstone($this->commandFile);
      $PID = $this->tombstone($this->pidFile);
      $unlocked = $this->lock(LOCK_UN);

      return $command && $PID && $unlocked;
   }

   /** Clear an existing owned state inode without requiring parent-directory writes. */
   private function tombstone (string $file): bool
   {
      if (is_link($file)) {
         return false;
      }
      if (is_file($file) === false) {
         return true;
      }
      if ($this->rewrite($file, '')) {
         return true;
      }

      // ? A project/storage administrator can own the protected directory but
      //   not a state file delegated to another runtime UID (e.g. cleanup after
      //   SIGKILL). It already has pathname authority by contract, so allow it
      //   to remove only a still-regular, contained PID/command inode when an
      //   in-place tombstone is impossible. The lock file never takes this path.
      $storage = @lstat(rtrim(BOOTGLY_STORAGE_DIR, '/'));
      $directory = @lstat(rtrim($this->pidsDir, '/'));
      $state = @lstat($file);
      if (
         str_starts_with($file, $this->pidsDir) === false
         || is_array($storage) === false
         || is_array($directory) === false
         || is_array($state) === false
         || ((int) $state['mode'] & 0170000) !== 0100000
         || $directory['uid'] !== $storage['uid']
         || (int) $directory['uid'] !== posix_geteuid()
         || ((int) $directory['mode'] & 0022) !== 0
      ) {
         return false;
      }

      return @unlink($file);
   }

   /**
    * Validate the shared state directory and reclaim legacy ownership on a
    * privileged launch. Its trusted owner/group are inherited from the storage
    * root, preserving an ordinary non-root project administrator's ability to
    * create new instances without granting a distinct runtime UID authority
    * over every service pathname.
    *
    * @return null|string `null` when the directory is safe; otherwise the
    *    check that refused it, naming the offending path (for the operator).
    */
   private function protect (): null|string
   {
      $storage = rtrim(BOOTGLY_STORAGE_DIR, '/');
      $pids = rtrim($this->pidsDir, '/');
      // ? Never follow a link at either level.
      foreach ([$storage, $pids] as $path) {
         if (is_link($path)) {
            return "symbolic link: {$path}";
         }
      }
      // ? The storage root is the trusted administrator: a real directory
      //   that nobody else may write into.
      $administrator = @lstat($storage);
      if (is_array($administrator) === false) {
         return "cannot be inspected (lstat failed): {$storage}";
      }
      if (((int) $administrator['mode'] & 0170000) !== 0040000) {
         return "not a directory: {$storage}";
      }
      if (((int) $administrator['mode'] & 0022) !== 0) {
         $mode = decoct((int) $administrator['mode'] & 07777);
         return "group/world-writable (0{$mode}): {$storage}";
      }
      $before = @lstat($pids);
      if (is_array($before) === false) {
         return "cannot be inspected (lstat failed): {$pids}";
      }
      if (((int) $before['mode'] & 0170000) !== 0040000) {
         return "not a directory: {$pids}";
      }

      // @ Reclaim a legacy runtime-owned directory on a privileged launch.
      $EUID = posix_geteuid();
      if ($EUID === 0) {
         if (@lchown($pids, (int) $administrator['uid']) === false) {
            return "lchown failed: {$pids}";
         }
         if (@lchgrp($pids, (int) $administrator['gid']) === false) {
            return "lchgrp failed: {$pids}";
         }
         if (@chmod($pids, 0755) === false) {
            return "chmod failed: {$pids}";
         }
      }

      // ? Re-check the same inode after any repair.
      $after = @lstat($pids);
      if (
         // @phpstan-ignore function.alreadyNarrowedType, identical.alwaysFalse (stat()/lstat() are never cached; PHPStan 2.3 remembers them until clearstatcache())
         is_array($after) === false
         || $before['dev'] !== $after['dev']
         || $before['ino'] !== $after['ino']
         || ((int) $after['mode'] & 0170000) !== 0040000
      ) {
         return "replaced while being checked: {$pids}";
      }
      if (((int) $after['mode'] & 0022) !== 0) {
         $mode = decoct((int) $after['mode'] & 07777);
         return "group/world-writable (0{$mode}): {$pids}";
      }
      if (
         $after['uid'] !== $administrator['uid']
         || $after['gid'] !== $administrator['gid']
      ) {
         $owner = "{$after['uid']}:{$after['gid']}";
         $trusted = "{$administrator['uid']}:{$administrator['gid']}";
         return "owner {$owner} differs from the storage root's {$trusted}: {$pids}";
      }

      // :
      return null;
   }

   /** @return resource|null Open a regular lock file without following links. */
   private function open (string $file): mixed
   {
      if (is_link($file)) {
         return null;
      }

      $before = @lstat($file);
      $previousMask = umask(0077);
      try {
         $Handle = $before === false
            ? @fopen($file, 'x+b')
            : @fopen($file, 'c+b');
         // @phpstan-ignore identical.alwaysTrue (intentional final-link race recheck)
         if ($Handle === false && $before === false && is_link($file) === false) {
            // Another safe creator may have won the exclusive race.
            // @phpstan-ignore function.impossibleType (stat()/lstat() are never cached; PHPStan 2.3 remembers them until clearstatcache())
            $before = @lstat($file);
            $Handle = @fopen($file, 'c+b');
         }
      }
      finally {
         umask($previousMask);
      }
      if ($Handle === false) {
         return null;
      }

      $opened = fstat($Handle);
      $after = @lstat($file);
      if (is_array($opened) === false || is_array($after) === false) {
         fclose($Handle);
         return null;
      }
      $same = $opened['dev'] === $after['dev']
         && $opened['ino'] === $after['ino']
         && ((int) $opened['mode'] & 0170000) === 0100000;
      if (is_array($before)) {
         $same = $same
            && $before['dev'] === $opened['dev']
            && $before['ino'] === $opened['ino'];
      }
      if ($same === false) {
         fclose($Handle);
         return null;
      }

      return $Handle;
   }

   /**
    * Force the instance lock inode to the exact 0600 mode `authenticate()`
    * demands, on the descriptor `open()` already proved to be the regular
    * file it validated.
    *
    * @param resource $Handle
    */
   private function seal (mixed $Handle): bool
   {
      $opened = @fstat($Handle);
      if (is_array($opened) === false) {
         return false;
      }

      // ? Already exact
      if (((int) $opened['mode'] & 0777) === 0600) {
         return true;
      }

      // ? Only the owner can repair it, and never through a symlink
      if (
         (int) $opened['uid'] !== posix_geteuid()
         || is_link($this->pidLockFile)
         || @chmod($this->pidLockFile, 0600) === false
      ) {
         return false;
      }

      // ! Re-read the DESCRIPTOR, not the pathname: if the path was swapped
      //   between the checks, the mode this handle reports is unchanged and
      //   the seal fails closed.
      $sealed = @fstat($Handle);

      // :
      return is_array($sealed) && ((int) $sealed['mode'] & 0777) === 0600;
   }

   /** @param resource $Handle */
   private function verify (mixed $Handle): bool
   {
      if (is_resource($Handle) === false || is_link($this->pidLockFile)) {
         return false;
      }

      $before = @lstat($this->pidLockFile);
      $opened = @fstat($Handle);
      $after = @lstat($this->pidLockFile);

      return is_array($before)
         && is_array($opened)
         && is_array($after)
         && ((int) $before['mode'] & 0170000) === 0100000
         && ((int) $opened['mode'] & 0170000) === 0100000
         && ((int) $after['mode'] & 0170000) === 0100000
         && $before['dev'] === $opened['dev']
         && $before['ino'] === $opened['ino']
         && $after['dev'] === $opened['dev']
         && $after['ino'] === $opened['ino'];
   }

   /** Rewrite an existing state inode when its directory is not writable. */
   private function rewrite (string $file, string $contents): bool
   {
      $Handle = $this->open($file);
      if ($Handle === null || flock($Handle, LOCK_EX) === false) {
         is_resource($Handle) && fclose($Handle);
         return false;
      }

      $written = false;
      try {
         if (ftruncate($Handle, 0) === false || rewind($Handle) === false) {
            return false;
         }
         $length = strlen($contents);
         $offset = 0;
         while ($offset < $length) {
            $bytes = fwrite($Handle, substr($contents, $offset));
            if ($bytes === false || $bytes === 0) {
               break;
            }
            $offset += $bytes;
         }
         $written = $offset === $length
            && fflush($Handle)
            && (!function_exists('fsync') || fsync($Handle));
      }
      finally {
         flock($Handle, LOCK_UN);
         fclose($Handle);
      }

      return $written;
   }
}
