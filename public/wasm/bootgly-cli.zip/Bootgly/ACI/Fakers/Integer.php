<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Rodrigo de Araujo Vieira Tecnologia da Informação LTDA and Bootgly contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ACI\Fakers;


use const PHP_INT_MAX;

use Bootgly\ACI\Faker;


/**
 * Integer faker with configurable inclusive bounds.
 */
final class Integer extends Faker
{
   /**
    * Minimum generated integer value.
    */
   public int $min = 0;
   /**
    * Maximum generated integer value.
    */
   public int $max = PHP_INT_MAX;


   /**
    * Generate one fake integer.
    */
   public function generate (): int
   {
      return $this->Randomizer->getInt($this->min, $this->max);
   }
}
