<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Bootgly and contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ACI;


use const WNOHANG;
use function cli_get_process_title;
use function cli_set_process_title;
use function pcntl_fork;
use function pcntl_waitpid;
use function posix_getpid;
use Closure;

use Bootgly\ACI\Process\Children;
use Bootgly\ACI\Process\Group;
use Bootgly\ACI\Process\Signals;
use Bootgly\ACI\Process\State;
use Bootgly\ACI\Process\User;


class Process
{


   // * Config
   // ...

   // * Data
   public string $title {
      get {
         $title = cli_get_process_title();

         if (!$title) {
            $title = 'Bootgly: unknown process';
         }

         return $title;
      }
      set (string $value) {
         cli_set_process_title($value);
      }
   }

   // * Metadata
   public private(set) Children $Children;

   public Signals $Signals;

   public State $State;

   public User $User;
   public Group $Group;

   public int $id {
      get => posix_getpid();
   }
   public string $level {
      get => $this->id === $this->master
         ? 'master'
         : 'child';
   }
   // # Id
   public static int $index = 0;
   public private(set) int $master;
   private bool $descended = false;
   // # Lifecycle
   public bool $stopping = false;
   public bool $reloading = false;


   public function __construct (string $id, null|string $instance = null)
   {
      $this->master = posix_getpid();

      $this->Children = new Children;

      $this->Signals  = new Signals($this);

      $this->State    = new State($id, $instance);

      $this->User     = new User;
      $this->Group    = new Group;
   }

   /**
    * Claim the current PID as this Process instance's master after an external
    * daemon fork. A worker created through descend() can never promote itself.
    */
   public function claim (): bool
   {
      if ($this->descended || $this->Children->PIDs !== []) {
         return false;
      }

      $this->master = posix_getpid();

      return true;
   }

   /**
    * Enter a forked worker with no inherited authority over sibling PIDs.
    */
   public function descend (int $index): bool
   {
      if ($this->id === $this->master) {
         return false;
      }

      $this->Children = new Children;
      self::$index = $index + 1;
      $this->descended = true;

      return true;
   }

   public function fork (int $workers, Closure $instance): void
   {
      for ($index = 0; $index < $workers; $index++) {
         $PID = pcntl_fork();

         // # Child process
         if ($PID === 0) {
            if ($this->descend($index) === false) {
               exit(1);
            }

            $instance($this, $index);

            exit(0);
         }
         // # Master process
         else if ($PID > 0) {
            $this->Children->push($PID, $index);
         }
         // Error
         else if ($PID === -1) {
            die('Could not fork process!');
         }
      }
   }

   /**
    * Recover exited children — reap via pcntl_waitpid.
    * Returns the dead worker index, PID, wait status and whether it was a
    * retiree for the caller to handle reforking: the status tells an orderly
    * exit (`pcntl_wifexited()` and `pcntl_wexitstatus()` read its code — a
    * worker recycle, say) from a crash or a kill (`pcntl_wifsignaled()`); a
    * retiree (`Children->retire()`) was already replaced in its slot, so its
    * exit never calls for another child.
    *
    * @return array{int,int,int,bool}|null [deadIndex, deadPID, status, retired] or null if none reaped.
    */
   public function recover (): null|array
   {
      // ? Do not refork workers we are intentionally stopping or draining for a
      //   reload — the master reaps those itself; reforking would fight the drain.
      if ($this->stopping || $this->reloading) {
         return null;
      }

      // @@ Drain every reapable TRACKED child, one per call: SIGCHLD coalesces,
      //   so a single delivery can cover several deaths — the caller keeps
      //   calling until this returns null.
      //
      //   Reaping is per known PID, never `waitpid(-1)`: this process must not
      //   consume the exit status of a child it does not own. The auxiliary
      //   children (Auto-TLS helper and certifier) are reaped by their own
      //   supervisors, and an application's `proc_open()` handles must stay
      //   reapable by PHP — stealing their status leaves `proc_get_status()`
      //   reporting a running process forever.
      foreach ($this->Children->PIDs as $index => $PID) {
         if (pcntl_waitpid($PID, $status, WNOHANG) !== $PID) {
            continue;
         }

         $this->Children->remove($PID);

         // :
         return [(int) $index, $PID, (int) $status, false];
      }
      // @@ The retirees: replaced in their slot, still reaped here
      foreach ($this->Children->retirees as $PID => $index) {
         if (pcntl_waitpid($PID, $status, WNOHANG) !== $PID) {
            continue;
         }

         $this->Children->remove($PID);

         // :
         return [$index, $PID, (int) $status, true];
      }

      // :
      return null;
   }
}
