<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Bootgly and contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ACI\Tests\Coverage\Drivers;


use function extension_loaded;
use function function_exists;
use function ini_get;
use LogicException;

use Bootgly\ACI\Tests\Coverage\Driver;


/**
 * ext-pcov backend.
 */
final class PCOV extends Driver
{
   /**
    * ext-pcov function used to start collection.
    */
   private const string FN_START = 'pcov\\start';
   /**
    * ext-pcov function used to stop collection.
    */
   private const string FN_STOP = 'pcov\\stop';
   /**
    * ext-pcov function used to collect hits.
    */
   private const string FN_COLLECT = 'pcov\\collect';


   /**
    * Ensure ext-pcov is available before the backend is used.
    */
   public function __construct ()
   {
      if (! extension_loaded('pcov')) {
         throw new LogicException('Pcov coverage requires ext-pcov');
      }

      // ? Loaded but disabled (the production default) collects nothing:
      //   pcov\collect() returns null instead of a hit map
      if ((bool) ini_get('pcov.enabled') === false) {
         throw new LogicException(
            'PCOV is loaded but disabled; set pcov.enabled=1 '
            . '(e.g. php -d pcov.enabled=1 bootgly test --coverage).'
         );
      }
   }

   /**
    * Start ext-pcov collection.
    */
   protected function begin (): void
   {
      $start = self::resolve(self::FN_START);
      $start();
   }

   /**
    * Stop ext-pcov collection.
    */
   protected function end (): void
   {
      $stop = self::resolve(self::FN_STOP);
      $stop();
   }

   /**
    * Collect and normalize ext-pcov line states.
    *
    * @return array<string,array<int,int>>
    */
   public function collect (): array
   {
      $collect = self::resolve(self::FN_COLLECT);
      /** @var array<string, array<int, int>> $raw */
      $raw = $collect();
      $out = [];
      foreach ($raw as $file => $lines) {
         $bucket = [];
         foreach ($lines as $line => $state) {
            $bucket[$line] = $state > 0 ? 1 : 0;
         }
         $out[$file] = $bucket;
      }
      return $out;
   }

   /**
    * @return callable-string
    */
   private static function resolve (string $function): string
   {
      if (! function_exists($function)) {
         throw new LogicException("Pcov coverage requires {$function}().");
      }

      return $function;
   }
}
