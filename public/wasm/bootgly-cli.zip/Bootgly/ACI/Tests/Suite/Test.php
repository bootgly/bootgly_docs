<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright 2023-present
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ACI\Tests\Suite;


use const PHP_EOL;
use const STR_PAD_BOTH;
use const STR_PAD_RIGHT;
use function array_reduce;
use function array_values;
use function count;
use function current;
use function file_put_contents;
use function gettype;
use function is_a;
use function microtime;
use function ob_end_clean;
use function ob_get_clean;
use function ob_start;
use function sprintf;
use function str_pad;
use function str_repeat;
use function strlen;
use AssertionError;
use Closure;
use Generator;
use ReflectionFunction;
use ReflectionIntersectionType;
use ReflectionNamedType;
use ReflectionType;
use ReflectionUnionType;
use Throwable;
use UnderflowException;

use Bootgly\ACI\Logs\Logger;
use Bootgly\ACI\Tests\Assertion;
use Bootgly\ACI\Tests\Assertions;
use Bootgly\ACI\Tests\Benchmark;
use Bootgly\ACI\Tests\Fixture;
use Bootgly\ACI\Tests\Results;
use Bootgly\ACI\Tests\Suite;
use Bootgly\ACI\Tests\Suite\Test\Specification;


class Test
{
   // * Data
   public Logger $Logger {
      get {
         if ( isSet($this->Logger) === false ) {
            $this->Logger = new Logger(channel: static::class);
         }

         return $this->Logger;
      }
   }


   public Suite $Suite;

   // * Config
   public Specification $Specification;
   // # Assertions
   /**
    * The descriptions of the Assertions.
    * @var array<string|null>
    */
   public array $descriptions = [];

   // * Data
   // # Assertions
   /**
    * The results of the Assertions.
    * @var array<bool|null>
    */
   protected array $results = [];

   // * Metadata
   private string $filename;
   // # Result
   private bool $passed;
   // # Output
   private false|string $debugged;
   // @ Profiling
   private float $started;
   private float $finished;
   private string $elapsed;
   // @ Reporting
   private null|AssertionError $AssertionError;
   // @ Retesting
   private null|bool $retested = null;


   /**
    * Test Case constructor.
    * 
    * @param Suite $Suite Test Suite instance
    * @param Specification $Specification Test case specification
    */
   public function __construct (Suite $Suite, Specification $Specification)
   {
      $this->Suite = $Suite;

      // * Config
      $this->Specification = $Specification;
      // ...inherited:
      $this->descriptions = [
         $this->Specification->description ?? null
      ];

      // * Data
      // ...inherited:
      $this->results = [];

      // * Metadata
      $this->filename = current($this->Suite->tests) ?: '';
      // # Output
      $this->debugged = false;
      // # Profiling
      $this->started = microtime(true);
      $this->finished = $this->started;
      $this->elapsed = Benchmark::format($this->started, $this->finished);
      // # Reporting
      $this->AssertionError = null;
   }
   public function __get (string $name): mixed
   {
      switch ($name) {
         case "passed":
            $this->passed = array_reduce(
               array: $this->results,
               callback: function ($accumulator, $assertion) {
                  return $accumulator && $assertion;
               },
               initial: true
            );

            return $this->passed;
      };

      return null;
   }

   private function describe (null|string $description, ?bool $status, string $indicator = '╟'): void
   {
      if ($description === null) {
         return;
      }
      if (Results::$enabled) {
         return;
      }

      // Indicator
      # ╚ • ╟ ─
      // Icon
      # ⮡ ↳➡️↪↪️ ✓✘ ✅❌
      $icon = match ($status) {
         // PASS
         true  => ' @#green:✓ @; ',
         // FAIL
         false => ' @#red:✘ @; ',
         // SKIP (null)
         default => ' @#yellow:─ @; ',
      };
      // Description
      $description = "@#white:{$description}@;";
      // Breakline
      $breakline = '@.;';

      $description = "{$indicator}{$icon}{$description}{$breakline}";

      $this->Logger->log(debug: $description);
   }
   private function describing (bool $status): void
   {
      $descriptions_count = count($this->descriptions);

      if (!$this->descriptions[0] || $descriptions_count === 1) return;

      $index = 1;
      foreach ($this->descriptions as $description) {
         if ($descriptions_count === 2 && $description === null && $index === 2)
            break;

         // description
         $description ??= 'Assertion @:info:#' . ($index - 1) . '@;';
         // status
         $status = (
            !$status && ($index === $descriptions_count || $index === 1)
         )
            ? false
            : true;
         $status = $index === 1 ? $status : $this->results[$index - 2];
         // indicator
         $indicator = match ($index) {
            1                   => '╟',
            $descriptions_count => '╚══',
            default             => '╟──',
         };

         $this->describe(
            $description,
            $status,
            $indicator
         );

         $index++;
      }
   }
   public function separate (): void
   {
      if (Results::$enabled) {
         return;
      }

      static $separatorLength;

      $line   = $this->Specification->Separator->line   ?? null;
      $left   = $this->Specification->Separator->left   ?? null;
      $header = $this->Specification->Separator->header ?? null;

      $width = Suite::$width + 30;

      if ($line) {
         if ($line !== true) {
            $separatorLength = strlen($line);
            $line = "@:i: {$line}  @;";

            // Text + `-`
            $line = str_pad($line, $width, '-', STR_PAD_BOTH);
         }
         else {
            $line = str_repeat('-', $width - 7);
         }

         $this->Logger->log(debug: "{$line} @.;");
      }

      if ($left) {
         $this->Logger->log(debug: "@.;            \033[3;90m{$left}:\033[0m @.;");
      }

      if ($header) {
         $header = '\\' .str_pad($header, $separatorLength ?? 0, ' ', STR_PAD_BOTH) . '/';
         $header = str_pad($header, $width - 7, ' ', STR_PAD_BOTH);

         $this->Logger->log(debug: "@#white:{$header} @;@.;");
      }
   }

   // # Test Case
   /**
    * Pretest the Test Case.
    *
    * @return bool
    */
   private function pretest (): bool
   {
      $retested = $this->retested ?? null;

      // @ Skip without output (used to skip with command arguments)
      if ($this->Specification->ignore ?? false) {
         $this->Suite->skipped++;
         return false;
      }

      if ($retested !== true) {
         $this->separate();
      }

      // @ Fixture lifecycle — idempotent: no-op if already Ready (e.g. when
      //   a domain runner like WPI HTTP_Server_CLI prepared the fixture
      //   before sending the request).
      $this->Specification->Fixture?->prepare();

      return true;
   }
   /**
    * Run the Test Case.
    * 
    * @param mixed ...$arguments
    *
    * @return void
    */
   public function test (mixed ...$arguments): void
   {
      $arguments = array_values($arguments);

      if ($this->pretest() === false) {
         $this->postest();
         return;
      }

      // ---

      // !
      $test = $this->Specification->test;
      $retest = $this->Specification->retest ?? null;
      $runtimeArguments = $arguments;

      try {
         ob_start();

         if ($test instanceof Assertions) {
            $test->Fixture ??= $this->Specification->Fixture;
            $Assertions = $test->run(...$runtimeArguments);
         }
         else {
            $runtimeArguments = $this->inject($runtimeArguments, $test);
            $Assertions = $test(...$runtimeArguments);
         }

         $this->debugged = ob_get_clean();

         if ($Assertions instanceof Generator !== true) {
            $message = 'The assertion must return boolean, string, NULL, Assertion or a Generator!';

            $Assertions = match (gettype($Assertions)) {
               'boolean', 'string' => [$Assertions],
               'object' => 
                  $Assertions instanceof Assertion
                  || $Assertions instanceof Assertions
                  ?: throw new AssertionError($message),
               'NULL' => [null],
               default => throw new AssertionError($message)
            };
         }

         /** @var Assertion|bool|string|null $Assertion */
         foreach ($Assertions as $Assertion) { // @phpstan-ignore-line
            if ($Assertion === null) { // ignore
               throw new UnderflowException;
            }

            // Assertion instance
            if ($Assertion instanceof Assertion) {
               if ($Assertion->skipped) { // skip
                  $this->descriptions[] = $Assertion::$description;
                  $this->results[] = null;
                  continue;
               }

               $Assertion->asserted ?:
                  throw new AssertionError(
                     message: 'Using the `->assert(...)` method is mandatory before returning `new Assertion`!'
                  );
   
               $this->descriptions[] = $Assertion::$description;
            }
            // $Assertion is FALSE or a string (Test failed!)
            else if ($Assertion === false || $Assertion !== true) {
               throw new AssertionError(
                  message: Assertion::$fallback ?? ($Assertion ?: 'Test failed!')
               );
            }
            // $Assertion is TRUE (Test passed!)
            else {
               $this->descriptions[] = Assertion::$description;
               Assertion::$description = null;
            }
   
            $this->results[] = true;
         }

         $this->postest();

         // ---
         if ($this->Suite->autoReport) {
            $this->pass();
         }
      }
      catch (AssertionError $AssertionError) {
         @ob_end_clean();

         $this->postest();

         // ---
         $this->AssertionError = $AssertionError;

         $this->descriptions[] = Assertion::$description;
         $this->results[] = false;

         if ($this->Suite->autoReport) {
            $this->fail($AssertionError->getMessage());
         }
      }
      catch (UnderflowException $Exception) {
         // @ ignore — but still run postest() so the fixture lifecycle
         //   completes even when an assertion yielded null.
         $this->postest();
      }
      catch (Throwable $Throwable) {
         @ob_end_clean();

         $this->postest();

         $retest = null;

         throw $Throwable;
      }
      finally {
         if ($retest) {
            $this->Specification->test = $retest;
            $this->Specification->retest = null;
            $this->retested = true;

            $passed = $this->__get('passed');
            $arguments = [$test, $passed, ...$arguments];

            $this->test(...$arguments);
         }
      }
   }

   /**
    * @param array<int,mixed> $arguments
    *
    * @return array<int,mixed>
    */
   private function inject (array $arguments, Closure $Closure): array
   {
      $Fixture = $this->Specification->Fixture;
      if ($Fixture === null) {
         return $arguments;
      }

      $Function = new ReflectionFunction($Closure);
      $parameters = $Function->getParameters();
      $Parameter = $parameters[count($arguments)] ?? null;

      if ($Parameter === null) {
         foreach ($parameters as $Candidate) {
            if ($Candidate->isVariadic()) {
               $Parameter = $Candidate;
               break;
            }
         }
      }

      if ($Parameter === null) {
         return $arguments;
      }

      if ($this->check($Parameter->getType(), $Fixture) === false) {
         return $arguments;
      }

      $arguments[] = $Fixture;

      return $arguments;
   }

   /**
    * Check if a reflected parameter type accepts the active Fixture.
    */
   private function check (null|ReflectionType $Type, Fixture $Fixture): bool
   {
      if ($Type === null) {
         return true;
      }

      if ($Type instanceof ReflectionUnionType) {
         foreach ($Type->getTypes() as $Inner) {
            if ($this->check($Inner, $Fixture)) {
               return true;
            }
         }

         return false;
      }

      if ($Type instanceof ReflectionIntersectionType) {
         foreach ($Type->getTypes() as $Inner) {
            if ($this->check($Inner, $Fixture) === false) {
               return false;
            }
         }

         return true;
      }

      if ($Type instanceof ReflectionNamedType) {
         $name = $Type->getName();
         if ($name === 'mixed' || $name === 'object') {
            return true;
         }
         if ($Type->isBuiltin()) {
            return false;
         }

         return is_a($Fixture, $name);
      }

      return false;
   }

   /**
    * Postest the Test Case.
    * 
    * @return void
    */
   private function postest (): void
   {
      #$this->debugged ??= ob_get_clean();

      $this->finished = microtime(true);

      $this->elapsed = Benchmark::format($this->started, $this->finished);

      // @ Fixture lifecycle — idempotent: no-op if already Disposed
      //   (when a domain runner already disposed before reaching here).
      $this->Specification->Fixture?->dispose();
   }

   // @ Reporting
   public function fail (null|string $message = null): void
   {
      $this->Suite->failed++;

      $case = sprintf('%03d', $this->Specification->case);
      $test = str_pad("{$this->filename}:", Suite::$width, ' ', STR_PAD_RIGHT);
      $elapsed = $this->elapsed;

      // @ output
      $help = $message ?? $this->AssertionError?->getMessage();
      if (Results::$enabled === false) {
         // header
         $this->Logger->log(debug: 
            "\033[30m\033[47m " . $case . " \033[0m" .
            "\033[0;30;41m FAIL \033[0m " .
            "@@:" . $test . " @;" .
            "\033[1;35m +" . $elapsed . "s\033[0m" . PHP_EOL
         );
         // assertions
         $this->describing(status: false);
         // fallback
         if ($help) {
            $this->Logger->log(debug: 
               " ↪️\033[91m" . $help . "\033[0m" .
               PHP_EOL . PHP_EOL
            );
         }

         // # Debugging
         $this->Logger->log(debug: $this->debugged ?: '');
      }

      // @ Record result for AI agent output
      Results::record(
         suite: $this->Suite->name,
         case: $this->Specification->case ?? 0,
         file: $this->filename,
         status: 'failed',
         message: $help,
         elapsedMs: ($this->finished - $this->started) * 1000
      );

      // @ exit
      if (Suite::$exitOnFailure && $this->Specification->retest === null) {
         $this->Suite->summarize();

         if (Results::$enabled) {
            file_put_contents('php://stdout', Results::toJSON());
         }

         exit(1);
      }
   }
   public function pass (): void
   {
      $this->Suite->passed++;

      $case = sprintf('%03d', $this->Specification->case);
      $test = str_pad($this->filename, Suite::$width, ' ', STR_PAD_RIGHT);
      $elapsed = $this->elapsed;

      // @ output
      if (Results::$enabled === false) {
         // header
         $this->Logger->log(debug: 
            "\033[47;30m " . $case . " \033[0m" .
            "\033[0;30;42m PASS \033[0m " .
            "\033[90m" . $test . "\033[0m" .
            "\033[1;35m +" . $elapsed . "s\033[0m" . PHP_EOL
         );
         // assertions
         $this->describing(status: true);
      }

      // @ Record result for AI agent output
      Results::record(
         suite: $this->Suite->name,
         case: $this->Specification->case ?? 0,
         file: $this->filename,
         status: 'passed',
         elapsedMs: ($this->finished - $this->started) * 1000
      );
   }
}
