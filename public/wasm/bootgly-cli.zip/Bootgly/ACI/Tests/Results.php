<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Bootgly and contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ACI\Tests;


use const JSON_UNESCAPED_SLASHES;
use const JSON_UNESCAPED_UNICODE;
use const PHP_EOL;
use function json_encode;
use function round;


class Results
{
   // * Config
   public static bool $enabled = false;

   // * Data
   public static null|string $agent = null;
   /**
    * Collected test case results.
    *
    * @var array<int,array{suite:string,case:int,file:string,status:string,message:?string,elapsed_ms:float}>
    */
   public static array $cases = [];

   // * Metadata
   // # Suites
   public static int $suitesTotal = 0;
   public static int $suitesFailed = 0;
   public static int $suitesSkipped = 0;
   public static int $suitesPassed = 0;
   // # Assertions
   public static int $assertions = 0;
   // # Time
   public static float $durationMs = 0;


   /**
    * Record a test case result.
    *
    * @param string $suite
    * @param int $case
    * @param string $file
    * @param string $status 'passed'|'failed'|'skipped'
    * @param null|string $message
    * @param float $elapsedMs
    *
    * @return void
    */
   public static function record (
      string $suite,
      int $case,
      string $file,
      string $status,
      null|string $message = null,
      float $elapsedMs = 0
   ): void
   {
      if (self::$enabled === false) {
         return;
      }

      self::$cases[] = [
         'suite'      => $suite,
         'case'       => $case,
         'file'       => $file,
         'status'     => $status,
         'message'    => $message,
         'elapsed_ms' => round($elapsedMs, 2),
      ];
   }

   /**
    * Compile the collected records into the structured result array.
    *
    * @return array<string,mixed>
    */
   public static function compile (): array
   {
      // @ Count cases
      $casesFailed = 0;
      $casesSkipped = 0;
      $casesPassed = 0;
      $failures = [];

      foreach (self::$cases as $entry) {
         match ($entry['status']) {
            'failed' => $casesFailed++,
            'skipped' => $casesSkipped++,
            'passed' => $casesPassed++,
            default => null,
         };

         if ($entry['status'] === 'failed') {
            $failures[] = [
               'suite'      => $entry['suite'],
               'case'       => $entry['case'],
               'file'       => $entry['file'],
               'message'    => $entry['message'],
               'elapsed_ms' => $entry['elapsed_ms'],
            ];
         }
      }

      // ! A suite may fail without any failed CASE recorded (an Error thrown
      //   inside a test body aborts the suite before its cases register) —
      //   the aggregate must not report "passed" over a failed suite
      // ! Every registered suite is accounted for. A fail-fast run ends
      //   inside the failing suite, so the ones after it never report an
      //   outcome — they are SKIPPED, and reporting only what ran made a
      //   partial run look like a complete one (`skipped: 0` over a total
      //   that had silently shrunk to the suites the run got to).
      $suitesSkipped = self::$suitesTotal - self::$suitesFailed - self::$suitesPassed;
      if ($suitesSkipped < 0) {
         $suitesSkipped = self::$suitesSkipped;
      }

      $result = [
         'result'     => ($casesFailed > 0 || self::$suitesFailed > 0) ? 'failed' : 'passed',
         'agent'      => self::$agent,
         'suites'     => [
            'total'   => self::$suitesTotal,
            'failed'  => self::$suitesFailed,
            'skipped' => $suitesSkipped,
            'passed'  => self::$suitesPassed,
         ],
         'cases'      => [
            'total'   => $casesFailed + $casesSkipped + $casesPassed,
            'failed'  => $casesFailed,
            'skipped' => $casesSkipped,
            'passed'  => $casesPassed,
         ],
         'assertions' => self::$assertions,
         'duration_ms' => round(self::$durationMs, 2),
      ];

      if ($failures !== []) {
         $result['failures'] = $failures;
      }

      return $result;
   }

   /**
    * Encode the compiled results as a single-line JSON document.
    *
    * @return string
    */
   public static function encode (): string
   {
      return json_encode(
         self::compile(),
         JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
      ) . PHP_EOL;
   }
}
