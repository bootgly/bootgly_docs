<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Rodrigo de Araujo Vieira Tecnologia da Informação LTDA and Bootgly contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ACI\Tests\Benchmark;

use RuntimeException;


/**
 * Execute benchmark children without sharing the harness output descriptors.
 */
final class Child
{
   private int $sequence = 0;


   public function __construct (private readonly Artifacts $Artifacts)
   {
   }

   /**
    * Execute one argv command and retain its stdout, stderr and exit status.
    *
    * @param array<int,string> $command
    * @param array<string,string>|null $environment Null inherits the current environment.
    *
    * @return array{
    *    exit:int,
    *    stdout:string,
    *    stderr:string,
    *    status:string
    * }
    */
   public function run (
      array $command,
      string $scope,
      null|array $environment = null,
      null|string $input = null,
   ): array
   {
      if ($command === [] || array_any($command, static fn (mixed $argument): bool => is_string($argument) === false)) {
         throw new RuntimeException('A benchmark child command must be a non-empty argv string list');
      }

      $scope = trim((string) preg_replace('/[^A-Za-z0-9._-]+/', '-', $scope), '-.');
      if ($scope === '') {
         $scope = 'child';
      }

      $this->sequence++;
      $token = sprintf('%04d-%s-%s', $this->sequence, $scope, bin2hex(random_bytes(8)));
      $stdoutRelative = "children/{$token}/stdout.log";
      $stderrRelative = "children/{$token}/stderr.log";
      $statusRelative = "children/{$token}/status.json";
      $stdout = $this->Artifacts->resolve($stdoutRelative);
      $stderr = $this->Artifacts->resolve($stderrRelative);
      $stdoutCapture = "{$stdout}.capture";
      $stderrCapture = "{$stderr}.capture";

      $descriptors = [
         0 => ['pipe', 'r'],
         1 => ['file', $stdoutCapture, 'xb'],
         2 => ['file', $stderrCapture, 'xb'],
      ];
      $pipes = [];
      $Process = proc_open(
         $command,
         $descriptors,
         $pipes,
         null,
         $environment,
         ['bypass_shell' => true]
      );

      if (is_resource($Process) === false) {
         @unlink($stdoutCapture);
         @unlink($stderrCapture);
         throw new RuntimeException("Can not start benchmark child: {$scope}");
      }

      if (isset($pipes[0]) && is_resource($pipes[0])) {
         if ($input !== null) {
            $length = strlen($input);
            $offset = 0;
            while ($offset < $length) {
               $bytes = fwrite($pipes[0], substr($input, $offset));
               if ($bytes === false || $bytes === 0) {
                  break;
               }
               $offset += $bytes;
            }
         }
         fclose($pipes[0]);
      }

      $exit = proc_close($Process);
      $stdoutPublished = @rename($stdoutCapture, $stdout);
      $stderrPublished = @rename($stderrCapture, $stderr);
      if ($stdoutPublished === false || $stderrPublished === false) {
         @unlink($stdoutCapture);
         @unlink($stderrCapture);
         @unlink($stdout);
         @unlink($stderr);
         throw new RuntimeException("Can not atomically publish child output: {$scope}");
      }
      clearstatcache(true, $stdout);
      clearstatcache(true, $stderr);

      $JSON = json_encode([
         'exit' => $exit,
         'stdout' => $this->Artifacts->relate($stdoutRelative),
         'stdout-bytes' => is_file($stdout) ? filesize($stdout) : 0,
         'stderr' => $this->Artifacts->relate($stderrRelative),
         'stderr-bytes' => is_file($stderr) ? filesize($stderr) : 0,
      ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n";
      $status = $this->Artifacts->write($statusRelative, $JSON);

      return [
         'exit' => $exit,
         'stdout' => $this->Artifacts->relate($stdoutRelative),
         'stderr' => $this->Artifacts->relate($stderrRelative),
         'status' => $status,
      ];
   }
}
