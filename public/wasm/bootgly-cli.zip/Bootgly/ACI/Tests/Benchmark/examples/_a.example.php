<?php

require __DIR__ . '/../../../../../autoload.php';

use Bootgly\ACI\Tests\Benchmark;

Benchmark::start('a');
sleep(1);
Benchmark::stop('a');

#Benchmark::show();
Benchmark::save();
