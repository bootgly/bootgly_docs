<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Bootgly and contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ACI\Tests\Assertion\Expectations\Finders;


use function is_string;
use function strpos;

use Bootgly\ACI\Tests\Asserting\Fallback;
use Bootgly\ACI\Tests\Assertion\Expectation\Finder;


class StartsWith extends Finder
{
   public function assert (mixed &$actual, mixed &$expected): bool
   {
      $needle = $this->needle ?? $expected;

      if (
         is_string($actual) === false
         || is_string($needle) === false
      ) {
         return false;
      }

      return strpos(
         haystack: $actual,
         needle: $needle
      ) === 0;
   }

   public function fail (mixed $actual, mixed $expected, int $verbosity = 0): Fallback
   {
      $needle = $this->needle ?? $expected;

      return new Fallback(
         'Failed asserting that the string "%s" starts with "%s".',
         [
            'actual' => $actual,
            'expected' => $needle
         ],
         $verbosity
      );
   }
}
