<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright 2023-present
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ACI\Tests\Assertion\Expectations\Finders;


use function is_string;
use function str_ends_with;

use Bootgly\ACI\Tests\Asserting\Fallback;
use Bootgly\ACI\Tests\Assertion\Expectation\Finder;


class EndsWith extends Finder
{
   public function assert (mixed &$actual, mixed &$expected): bool
   {
      $needle = $this->needle ?? $expected;

      if (
         is_string($actual) === false
         || is_string($needle) === false
      ) {
         return false;
      }

      return str_ends_with($actual, $needle);
   }

   public function fail (mixed $actual, mixed $expected, int $verbosity = 0): Fallback
   {
      $needle = $this->needle ?? $expected;

      return new Fallback(
         'Failed asserting that the string "%s" ends with "%s".',
         [
            'actual' => $actual,
            'expected' => $needle
         ],
         $verbosity
      );
   }
}
