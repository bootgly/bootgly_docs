<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Bootgly and contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ACI\Tests;


use function count;
use function microtime;
use Throwable;

use Bootgly\ABI\Debugging\Data\Throwables\Exceptions;
use Bootgly\ACI\Logs\Logger;
use Bootgly\ACI\Tests\Assertions;
use Bootgly\ACI\Tests\Results;
use Bootgly\ACI\Tests\Suite;


class Suites
{
   // * Data
   public Logger $Logger {
      get {
         if ( isSet($this->Logger) === false ) {
            $this->Logger = new Logger(channel: static::class);
         }

         return $this->Logger;
      }
   }

   // * Config
   /**
    * The Test Suite directories.
    *
    * @var array<string>
    */
   public array $directories;

   // * Metadata
   // # Status
   public int $failed;
   public int $passed;
   public int $skipped;
   // # Stats
   public static int $count = 0;
   public int $total;
   // # Time
   public float $started;
   public float $finished;


   /**
    * Suites constructor.
    *
    * @param array<string> $directories The Test Suite directories.
    */
   public function __construct (array $directories)
   {
      // * Config
      $this->directories = $directories;

      // * Metadata
      // # Status
      $this->failed = 0;
      $this->passed = 0;
      $this->skipped = 0;
      // # Stats
      // self::$count
      $this->total = count($this->directories);
      // # Time
      $this->started = microtime(true);
      // $finished
   }

   public function iterate (
      int $suite,
      int $case,
      callable $iterator
   ): void
   {
      foreach ($this->directories as $index => $dir) {
         self::$count++;

         if ($suite > 0 && $suite !== $index + 1) {
            $this->skipped++;
            continue;
         }

         try {
            /** @var null|true|Suite $Suite */
            $Suite = $iterator($dir, $case, $index + 1);

            // ? A suite whose cases failed returns normally — count the
            //   failure here or the run summary (and the exit code, when no
            //   exit-on-failure fired) would report it as passed
            if ($Suite instanceof Suite && $Suite->failed > 0) {
               $this->failed++;

               continue;
            }

            $this->passed++;
         }
         catch (Throwable $T) {
            Exceptions::collect($T);
            $this->failed++;
         }
      }
   }

   /**
    * Summarize Test Suites.
    *
    * @return void
    */
   public function summarize (): void
   {
      // # Result
      $failed = '@:error:' . $this->failed . ' failed @;';
      $skipped = '@:notice:' . $this->skipped . ' skipped @;';
      $passed = '@:success:' . $this->passed . ' passed @;';
      // # Stats
      $cases = '@:info:' . Assertions::$count . ' @;';
      $total = '@:info:' . $this->total . ' @;';
      // # Time
      $started = $this->started;
      $finished = $this->finished = microtime(true);

      // @ Feed stats for AI agent output
      Results::$suitesTotal = $this->total;
      Results::$suitesFailed = $this->failed;
      Results::$suitesSkipped = $this->skipped;
      Results::$suitesPassed = $this->passed;
      Results::$assertions = Assertions::$count;
      Results::$durationMs = ($finished - $started) * 1000;

      if (Results::$enabled) {
         return;
      }

      // duration
      $duration = Benchmark::format($started, $finished);
      $duration = "@#Magenta:" . $duration . "s @;";

      $ran = '@#Black:' . 'Ran all test suites. @;';

      // TODO temp
      $this->Logger->log(debug: <<<TESTS

      @#white:============================================================ @;
      @#white:Test Suites: @; {$failed}, {$skipped}, {$passed}
      @#white:# of Test Suites: @; {$total}
      @#white:# of Test Cases: @; {$cases}
      @#white:Total Duration: @; {$duration}
      {$ran}
      @#white:============================================================ @;
      \n
      TESTS);
   }
}
