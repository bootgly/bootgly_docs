<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Bootgly and contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ACI\Logs\Formatters;


use const JSON_INVALID_UTF8_SUBSTITUTE;
use const JSON_UNESCAPED_SLASHES;
use const JSON_UNESCAPED_UNICODE;
use const PHP_EOL;
use function date;
use function floor;
use function json_encode;
use function sprintf;

use Bootgly\ABI\Code\__String\Controls;
use Bootgly\ABI\Code\__String\Escapeable\Text\Formattable;
use Bootgly\ABI\Templates\Template\Escaped as TemplateEscaped;
use Bootgly\ACI\Logs\Data\Display;
use Bootgly\ACI\Logs\Data\Levels;
use Bootgly\ACI\Logs\Data\Record;
use Bootgly\ACI\Logs\Formatter;


class Line implements Formatter
{
   use Formattable;

   // * Data
   /** A fixed `Display` segment mask; null follows the process-wide `Display::$segments`. */
   private null|int $segments;


   /**
    * @param null|int $segments A fixed `Display` segment mask for a destination that must not
    *   follow the terminal (a system logger, a file) — null follows `Display::$segments`.
    */
   public function __construct (null|int $segments = null)
   {
      $this->segments = $segments;
   }

   /**
    * Render a record as a single human/terminal line with ANSI colors.
    *
    * Each part is gated by its `Display` segment flag — the message is always the content,
    * timestamp / channel / severity / context wrap around it when their flag is enabled.
    *
    * No part can drive a UTF-8 terminal: control characters are escaped visibly
    * (`Controls::escape()`) before the message markup is rendered — the message keeps its tabs,
    * line feeds and complete SGR sequences, the channel and the context keep none. Bytes that are
    * not UTF-8 are written as they are.
    *
    * @param Record $Record The record to format.
    * @return string The formatted line.
    */
   public function format (Record $Record): string
   {
      $segments = $this->segments ?? Display::$segments;

      $color = $this->color($Record->Level);

      // @ [timestamp]
      $when = '';
      if (($segments & Display::TIMESTAMP) !== 0) {
         $seconds = (int) $Record->timestamp;
         $micro = sprintf('%06d', (int) (($Record->timestamp - floor($Record->timestamp)) * 1000000));

         $when = self::wrap(self::_BLACK_BRIGHT_FOREGROUND)
               . '[' . date('Y-m-d\TH:i:s', $seconds) . ".$micro" . date('P', $seconds) . '] '
               . self::_RESET_FORMAT;
      }

      // @ Origin: channel and/or severity, each toggled on its own
      $origin = '';
      if (($segments & Display::CHANNEL) !== 0 && $Record->channel !== '') {
         $origin = Controls::escape($Record->channel);
      }
      if (($segments & Display::SEVERITY) !== 0) {
         if ($origin !== '') {
            $origin .= '.';
         }
         $origin .= self::wrap($color) . $Record->Level->render() . self::_RESET_FORMAT;
      }
      if ($origin !== '') {
         $origin .= ': ';
      }

      // @ Message
      $message = '';
      if (($segments & Display::MESSAGE) !== 0) {
         $message = self::wrap($color)
                  . TemplateEscaped::render(Controls::escape($Record->message, "\t\n", SGR: true))
                  . self::_RESET_FORMAT;
      }

      // @ Inline context dump
      $context = '';
      if (($segments & Display::CONTEXT) !== 0 && $Record->context !== []) {
         $encoded = json_encode($Record->context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
         if ($encoded !== false) {
            // ! json_encode() leaves DEL and C1 raw under JSON_UNESCAPED_UNICODE
            $context = ' '
                     . self::wrap(self::_BLACK_BRIGHT_FOREGROUND) . Controls::escape($encoded) . self::_RESET_FORMAT;
         }
      }

      // @ Newline for every selection except the compact inline message
      $eol = $segments === Display::MESSAGE ? '' : PHP_EOL;

      // :
      return "$when$origin$message$context$eol";
   }

   // # Translating
   private function color (Levels $Level): string
   {
      return match ($Level) {
         Levels::Emergency => self::_RED_BOLD,
         Levels::Alert     => self::_MAGENTA_BOLD,
         Levels::Critical  => self::_MAGENTA_FOREGROUND,
         Levels::Error     => self::_RED_BRIGHT_FOREGROUND,
         Levels::Warning   => self::_YELLOW_BOLD,
         Levels::Notice    => self::_CYAN_FOREGROUND,
         Levels::Info      => self::_GREEN_BOLD,
         Levels::Debug     => self::_WHITE_FOREGROUND,
      };
   }
}
