<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Rodrigo de Araujo Vieira Tecnologia da Informação LTDA and Bootgly contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ACI;


use Random\Engine\Mt19937;
use Random\Randomizer;


/**
 * Abstract data faker — deterministic when seeded.
 *
 * Subclasses override generate() to return a value of their domain
 * (Email, UUID, Integer, ...). The trait Fakers exposes a single
 * fake($kind, $seed) entry-point.
 */
abstract class Faker
{
   /**
    * Randomizer used by concrete fakers to generate deterministic values.
    */
   public private(set) Randomizer $Randomizer;

   // * Config
   /**
    * The seed used to initialize the Randomizer, if any.
    */
   public private(set) null|int $seed = null;


   /**
    * Create a Faker, optionally seeded for deterministic output.
    */
   public function __construct (null|int $seed = null)
   {
      $this->seed = $seed;
      $this->Randomizer = $seed === null
         ? new Randomizer()
         : new Randomizer(new Mt19937($seed));
   }

   /**
    * Produce one fake value.
    */
   abstract public function generate (): mixed;
}
