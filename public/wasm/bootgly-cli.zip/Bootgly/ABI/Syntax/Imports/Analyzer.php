<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Bootgly and contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ABI\Syntax\Imports;


use const T_AS;
use const T_CASE;
use const T_CLASS;
use const T_COMMENT;
use const T_CONST;
use const T_DOC_COMMENT;
use const T_ENUM;
use const T_EXTENDS;
use const T_FUNCTION;
use const T_IMPLEMENTS;
use const T_INSTANCEOF;
use const T_INTERFACE;
use const T_NAME_FULLY_QUALIFIED;
use const T_NAME_QUALIFIED;
use const T_NAMESPACE;
use const T_NEW;
use const T_NS_SEPARATOR;
use const T_NULLSAFE_OBJECT_OPERATOR;
use const T_OBJECT_OPERATOR;
use const T_PAAMAYIM_NEKUDOTAYIM;
use const T_STRING;
use const T_TRAIT;
use const T_USE;
use function count;
use function explode;
use function file_get_contents;
use function in_array;
use function is_array;
use function preg_match;
use function preg_match_all;
use function str_contains;
use function strcasecmp;
use function strlen;
use function strpos;
use function strrpos;
use function strtolower;
use function substr;
use function token_get_all;
use function trim;

use Bootgly\ABI\Syntax\Analyzers;
use Bootgly\ABI\Syntax\Analyzers\Issue;
use Bootgly\ABI\Syntax\Builtins;
use Bootgly\ABI\Syntax\Imports\Analyzer\Result;
use Bootgly\ABI\Syntax\Imports\Analyzer\Tokens;


class Analyzer extends Analyzers
{
   // * Config
   // * Data
   // * Metadata

   // @ Token IDs for skipping function-call detection
   private const array SKIP_BEFORE_FUNCTION = [
      T_OBJECT_OPERATOR,
      T_PAAMAYIM_NEKUDOTAYIM,
      T_NULLSAFE_OBJECT_OPERATOR,
      T_FUNCTION,
      T_CLASS,
      T_INTERFACE,
      T_TRAIT,
      T_ENUM,
      T_NEW,
      T_CONST,
   ];

   // @ Token IDs for class-reference contexts
   private const array CLASS_CONTEXT_TOKENS = [
      T_NEW,
      T_EXTENDS,
      T_IMPLEMENTS,
      T_INSTANCEOF,
   ];



   /**
    * Analyze a PHP file for import violations.
    *
    * @param string $file Absolute path to PHP file
    *
    * @return Result
    */
   public function analyze (string $file): Result
   {
      $source = file_get_contents($file);
      if ($source === false) {
         return new Result(
            file: $file,
            source: '',
            namespace: '',
            imports: [],
            importRange: ['start' => -1, 'end' => -1],
            symbols: [],
            issues: []
         );
      }

      $tokens = token_get_all($source);
      $count = count($tokens);
      $Tokens = new Tokens($tokens, $count);

      // * Data
      $namespace = '';
      /** @var array<int,array{symbol:string,kind:string,global:bool,line:int,alias:string}> */
      $imports = [];
      $importStart = -1;
      $importEnd = -1;
      /** @var array<string,array{kind:string,lines:array<int>}> */
      $usedSymbols = [];
      /** @var array<int,Issue> */
      $issues = [];

      // * Metadata
      $importedFunctions = [];
      $importedConstants = [];
      $importedClasses = [];
      $inClassBody = 0;

      // ---
      // ? Imports are per namespace block, the body scan is per file: a file
      //   with more than one block is not linted — and the result says so
      if ($this->count($tokens, $count) > 1) {
         return new Result(
            file: $file,
            source: $source,
            namespace: '',
            imports: [],
            importRange: ['start' => -1, 'end' => -1],
            symbols: [],
            issues: [],
            notice: 'More than one namespace declared — the file is not linted'
         );
      }

      // Phase 1: Extract namespace and imports
      // ---
      $bodyStart = 0;
      for ($i = 0; $i < $count; $i++) {
         $token = $tokens[$i];

         if (!is_array($token)) {
            continue;
         }

         // @ Namespace — only a declaration names the file's namespace: the
         //   keyword is also a legal argument label, method or constant name
         if ($token[0] === T_NAMESPACE) {
            if ($this->check($tokens, $count, $i) === false) {
               continue;
            }

            $namespace = $this->parse($Tokens, $i);
            continue;
         }

         // @ Use statements (top-level only)
         if ($token[0] === T_USE) {
            // ? Skip closure `use` (e.g., `function () use ($var)`)
            if ($Tokens->rewind($i) === ')') {
               continue;
            }

            // ? Skip trait `use` inside class body
            if ($inClassBody > 0) {
               continue;
            }

            $import = $this->extract($Tokens, $i);
            if ($import === null) {
               continue;
            }

            foreach ($import['items'] as $item) {
               $imports[] = $item;

               match ($item['kind']) {
                  'function' => $importedFunctions[strtolower($item['alias'])] = true,
                  'const'    => $importedConstants[$item['alias']] = true,
                  'class'    => $importedClasses[strtolower($item['alias'])] = true,
                  default    => null,
               };
            }

            // @ Track import block range
            if ($importStart === -1) {
               $importStart = $import['byteStart'];
            }
            $importEnd = $import['byteEnd'];
            $bodyStart = $i;

            continue;
         }

         // @ Track class body depth for trait `use` detection
         if ($token[0] === T_CLASS || $token[0] === T_INTERFACE
            || $token[0] === T_TRAIT || $token[0] === T_ENUM
         ) {
            // Find opening brace
            for ($j = $i + 1; $j < $count; $j++) {
               if ($tokens[$j] === '{') {
                  $inClassBody++;
                  $i = $j;
                  break;
               }
            }
            $bodyStart = $i;
            continue;
         }
      }

      // @ Skip files without a namespace declaration
      if ($namespace === '') {
         return new Result(
            file: $file,
            source: $source,
            namespace: '',
            imports: [],
            importRange: ['start' => -1, 'end' => -1],
            symbols: [],
            issues: []
         );
      }

      // ---
      // Phase 1.5: Pre-scan for locally-defined functions
      // ---
      $localFunctions = [];
      $classDepth = 0;
      for ($i = 0; $i < $count; $i++) {
         $token = $tokens[$i];

         if ($token === '{') {
            $classDepth++;
            continue;
         }
         if ($token === '}') {
            $classDepth--;
            continue;
         }

         if (!is_array($token)) {
            continue;
         }

         // @ Track class/interface/trait/enum bodies
         if (in_array($token[0], [T_CLASS, T_INTERFACE, T_TRAIT, T_ENUM], true)) {
            for ($j = $i + 1; $j < $count; $j++) {
               if ($tokens[$j] === '{') {
                  $classDepth++;
                  $i = $j;
                  break;
               }
            }
            continue;
         }

         // @ Find function definitions outside class bodies
         if ($token[0] === T_FUNCTION && $classDepth === 0) {
            $nextToken = $Tokens->advance($i);
            if ($nextToken !== null && is_array($nextToken) && $nextToken[0] === T_STRING) {
               $localFunctions[strtolower($nextToken[1])] = true;
            }
         }
      }

      // ---
      // Phase 2: Scan body for symbol usage
      // ---
      $inClassBody = 0;
      for ($i = 0; $i < $count; $i++) {
         $token = $tokens[$i];

         // @ Track brace depth
         if ($token === '{') {
            continue;
         }
         if ($token === '}') {
            continue;
         }

         if (!is_array($token)) {
            continue;
         }

         // @ Skip comments
         if ($token[0] === T_COMMENT || $token[0] === T_DOC_COMMENT) {
            continue;
         }

         // @ Skip use statements, namespace decl
         if ($token[0] === T_USE || $token[0] === T_NAMESPACE) {
            continue;
         }

         // @ Detect backslash-prefixed global symbols: \func(), \CONST, \Class::
         if ($token[0] === T_NAME_FULLY_QUALIFIED) {
            $fullName = $token[1]; // e.g. "\str_pad"
            $bsLine = $token[2];

            // @ Only handle single-segment: \name (not \Foo\Bar)
            $stripped = substr($fullName, 1);
            if (str_contains($stripped, '\\')) {
               continue;
            }

            $bsName = $stripped;
            $afterToken = $Tokens->advance($i);
            $bsOffset = $Tokens->locate($i);
            $bsKind = null;

            // * function: \func(
            if ($afterToken === '(') {
               if (Builtins::check($bsName, 'function')
                  || isset($importedFunctions[strtolower($bsName)])
                  || isset($localFunctions[strtolower($bsName)])
               ) {
                  $bsKind = 'function';
               }
            }
            // * constant: \ALL_CAPS
            else if ($this->detect($bsName)) {
               if (Builtins::check($bsName, 'const')
                  || isset($importedConstants[$bsName])
               ) {
                  $bsKind = 'const';
               }
            }
            // * class: \Class::
            else if (is_array($afterToken) && $afterToken[0] === T_PAAMAYIM_NEKUDOTAYIM) {
               if (Builtins::check($bsName, 'class')
                  || isset($importedClasses[strtolower($bsName)])
               ) {
                  $bsKind = 'class';
               }
            }

            if ($bsKind !== null) {
               $this->track($usedSymbols, $bsName, $bsKind, $bsLine);

               // @ backslash_prefix issue (for body fix)
               $issues[] = new Issue(
                  type: 'backslash_prefix',
                  symbol: $bsName,
                  kind: $bsKind,
                  line: $bsLine,
                  message: "Remove \\ prefix: \\{$bsName} → use explicit import",
                  offset: $bsOffset
               );

               // @ missing_import issue (if not already imported or locally defined)
               $imported = match ($bsKind) {
                  'function' => isset($importedFunctions[strtolower($bsName)])
                     || isset($localFunctions[strtolower($bsName)]),
                  'const'    => isset($importedConstants[$bsName]),
                  'class'    => isset($importedClasses[strtolower($bsName)]),
               };

               if (!$imported) {
                  $importLabel = match ($bsKind) {
                     'function' => "use function {$bsName};",
                     'const'    => "use const {$bsName};",
                     'class'    => "use {$bsName};",
                  };

                  $issues[] = new Issue(
                     type: 'missing_import',
                     symbol: $bsName,
                     kind: $bsKind,
                     line: $bsLine,
                     message: "Missing import: {$importLabel}"
                  );
               }
            }

            continue;
         }

         if ($token[0] !== T_STRING) {
            continue;
         }

         $name = $token[1];
         $line = $token[2];

         // @ Get previous meaningful token
         $prevToken = $Tokens->rewind($i);
         // @ Get next meaningful token
         $nextToken = $Tokens->advance($i);

         // @ Detect function calls: T_STRING followed by `(`
         if ($nextToken === '(') {
            // ? Skip if preceded by object/static access, function/class/const declaration
            if ($prevToken !== null && is_array($prevToken)
               && in_array($prevToken[0], self::SKIP_BEFORE_FUNCTION, true)
            ) {
               continue;
            }

            // ? Skip if already imported
            if (isset($importedFunctions[strtolower($name)])) {
               $this->track($usedSymbols, $name, 'function', $line);
               continue;
            }

            // ? Skip locally-defined functions
            if (isset($localFunctions[strtolower($name)])) {
               $this->track($usedSymbols, $name, 'function', $line);
               continue;
            }

            // ? Check if it's a builtin function
            if (Builtins::check($name, 'function')) {
               $this->track($usedSymbols, $name, 'function', $line);
               $issues[] = new Issue(
                  type: 'missing_import',
                  symbol: $name,
                  kind: 'function',
                  line: $line,
                  message: "Missing import: use function {$name};"
               );
            }

            continue;
         }

         // @ Detect constant usage: ALL_CAPS T_STRING
         if ($this->detect($name)) {
            // ? Skip if preceded by const keyword, namespace/use, or object access
            if ($prevToken !== null && is_array($prevToken)
               && in_array($prevToken[0], [
                  T_CONST, T_OBJECT_OPERATOR, T_PAAMAYIM_NEKUDOTAYIM,
                  T_NULLSAFE_OBJECT_OPERATOR, T_NAMESPACE, T_USE,
                  T_CASE,
               ], true)
            ) {
               continue;
            }

            // ? Skip class constant declarations — typed (`const string NAME =`)
            //   or listed (`const A = 1, B = 2`): the statement the name sits in
            //   starts with `const`, whatever lies between
            if ($nextToken === '=' && $this->trace($tokens, $i)) {
               continue;
            }

            // ? Skip if this looks like a class constant (Class::CONST)
            if ($prevToken !== null && is_array($prevToken)
               && $prevToken[0] === T_PAAMAYIM_NEKUDOTAYIM
            ) {
               continue;
            }

            // ? Skip if already imported
            if (isset($importedConstants[$name])) {
               $this->track($usedSymbols, $name, 'const', $line);
               continue;
            }

            // ? Check if it's a builtin constant
            if (Builtins::check($name, 'const')) {
               $this->track($usedSymbols, $name, 'const', $line);
               $issues[] = new Issue(
                  type: 'missing_import',
                  symbol: $name,
                  kind: 'const',
                  line: $line,
                  message: "Missing import: use const {$name};"
               );
            }

            continue;
         }

         // @ Detect class reference: `new X`, `X::`, type hints, catch, extends, implements
         if ($prevToken !== null && is_array($prevToken)
            && in_array($prevToken[0], self::CLASS_CONTEXT_TOKENS, true)
         ) {
            // ? Skip if already imported
            if (isset($importedClasses[strtolower($name)])) {
               $this->track($usedSymbols, $name, 'class', $line);
               continue;
            }

            // ? Check if it's a builtin class
            if (Builtins::check($name, 'class')) {
               $this->track($usedSymbols, $name, 'class', $line);
               $issues[] = new Issue(
                  type: 'missing_import',
                  symbol: $name,
                  kind: 'class',
                  line: $line,
                  message: "Missing import: use {$name};"
               );
            }

            continue;
         }

         // @ Detect static access: `X::`
         if (is_array($nextToken) && $nextToken[0] === T_PAAMAYIM_NEKUDOTAYIM) {
            if (in_array(strtolower($name), ['self', 'static', 'parent'], true)) {
               continue;
            }

            if (isset($importedClasses[strtolower($name)])) {
               $this->track($usedSymbols, $name, 'class', $line);
               continue;
            }

            if (Builtins::check($name, 'class')) {
               $this->track($usedSymbols, $name, 'class', $line);
               $issues[] = new Issue(
                  type: 'missing_import',
                  symbol: $name,
                  kind: 'class',
                  line: $line,
                  message: "Missing import: use {$name};"
               );
            }
         }
      }

      // ---
      // Phase 3: Validate import ordering
      // ---
      $this->validate($imports, $issues);

      // @ Build import range
      $importRange = [
         'start' => $importStart,
         'end'   => $importEnd,
      ];

      // ---
      // Phase 4: Report anything inside the range a rewrite would destroy
      // ---
      $this->survey($Tokens, $tokens, $count, $source, $importRange, $issues);

      // ---
      // Phase 5: Report imports the body never names
      // ---
      if ($imports !== []) {
         $this->prune($imports, $this->sweep($tokens, $count, $importRange), $issues);
      }

      return new Result(
         file: $file,
         source: $source,
         namespace: $namespace,
         imports: $imports,
         importRange: $importRange,
         symbols: $usedSymbols,
         issues: $issues
      );
   }

   /**
    * Parse namespace name from tokens.
    *
    * @param Tokens $Tokens
    * @param int $i Current position (at T_NAMESPACE)
    *
    * @return string
    */
   private function parse (Tokens $Tokens, int &$i): string
   {
      $tokens = &$Tokens->items;
      $count = $Tokens->count;

      $name = '';
      $i++;
      while ($i < $count) {
         $token = $tokens[$i];
         if ($token === ';' || $token === '{') {
            break;
         }
         if (is_array($token)) {
            if ($token[0] === T_STRING || $token[0] === T_NAME_QUALIFIED
               || $token[0] === T_NAME_FULLY_QUALIFIED || $token[0] === T_NS_SEPARATOR
            ) {
               $name .= $token[1];
            }
         }
         $i++;
      }

      return trim($name);
   }

   /**
    * Extract a use statement (single or grouped).
    *
    * @param Tokens $Tokens
    * @param int $i Current position (at T_USE)
    *
    * @return null|array{items:array<int,array{symbol:string,kind:string,global:bool,line:int,alias:string}>,byteStart:int,byteEnd:int}
    */
   private function extract (Tokens $Tokens, int &$i): null|array
   {
      $tokens = &$Tokens->items;
      $count = $Tokens->count;

      $startToken = $tokens[$i];
      $byteStart = $Tokens->locate($i);
      /** @var array{int,string,int} $startToken */
      $line = $startToken[2];

      $i++;
      $kind = 'class';
      $parts = '';
      $items = [];
      $grouped = false;
      $prefix = '';

      while ($i < $count) {
         $token = $tokens[$i];

         if ($token === ';') {
            $byteEnd = $Tokens->locate($i, true);

            $symbol = trim($parts);
            if ($symbol !== '') {
               // ! The last item of a group is flushed here instead of at a comma, so it
               //   needs the same prefix the comma branch applies — without it the item
               //   is recorded under its bare short name
               $fullSymbol = $grouped ? $prefix . $symbol : $symbol;
               $alias = $this->resolve($fullSymbol);
               $items[] = [
                  'symbol' => $fullSymbol,
                  'kind'   => $kind,
                  'global' => !str_contains($fullSymbol, '\\'),
                  'line'   => $line,
                  'alias'  => $alias,
               ];
            }
            break;
         }

         if ($token === '{') {
            $grouped = true;
            $prefix = trim($parts);
            $parts = '';
            $i++;
            continue;
         }

         if ($token === '}') {
            $i++;
            continue;
         }

         if ($token === ',') {
            $symbol = trim($parts);
            if ($symbol !== '') {
               $fullSymbol = $grouped ? $prefix . $symbol : $symbol;
               $alias = $this->resolve($fullSymbol);
               $items[] = [
                  'symbol' => $fullSymbol,
                  'kind'   => $kind,
                  'global' => !str_contains($fullSymbol, '\\'),
                  'line'   => $line,
                  'alias'  => $alias,
               ];
            }
            $parts = '';
            $i++;
            continue;
         }

         if (is_array($token)) {
            if ($token[0] === T_FUNCTION) {
               $kind = 'function';
            }
            else if ($token[0] === T_CONST) {
               $kind = 'const';
            }
            else if ($token[0] === T_STRING || $token[0] === T_NAME_QUALIFIED
               || $token[0] === T_NAME_FULLY_QUALIFIED || $token[0] === T_NS_SEPARATOR
            ) {
               $parts .= $token[1];
            }
            else if ($token[0] === T_AS) {
               $parts .= ' as ';
            }
         }

         $i++;
      }

      if ($items === []) {
         return null;
      }

      return [
         'items'     => $items,
         'byteStart' => $byteStart,
         'byteEnd'   => $byteEnd ?? $byteStart,
      ];
   }

   /**
    * Get the alias (short name) of an import symbol.
    *
    * @param string $symbol Full symbol (e.g., 'Bootgly\CLI\Command')
    *
    * @return string Alias (e.g., 'Command')
    */
   private function resolve (string $symbol): string
   {
      // @ Handle "as" aliases
      if (str_contains($symbol, ' as ')) {
         $parts = explode(' as ', $symbol);
         return trim($parts[1]);
      }

      $pos = strrpos($symbol, '\\');
      if ($pos === false) {
         return $symbol;
      }

      return substr($symbol, $pos + 1);
   }

   /**
    * Detect if a name looks like a constant (ALL_CAPS with underscores).
    *
    * @param string $name
    *
    * @return bool
    */
   private function detect (string $name): bool
   {
      if (strlen($name) < 2) {
         return false;
      }

      // @ Language keywords/literals that look like constants but are not importable
      static $keywords = [
         'NULL'  => true, 'TRUE'  => true, 'FALSE' => true,
         'SELF'  => true, 'STATIC' => true, 'PARENT' => true,
      ];
      if (isset($keywords[$name])) {
         return false;
      }

      // @ Must be ALL_CAPS (allow digits and underscores)
      return preg_match('/^[A-Z][A-Z0-9_]+$/', $name) === 1;
   }

   /**
    * Track a used symbol.
    *
    * @param array<string,array{kind:string,lines:array<int>}> $symbols
    * @param string $name
    * @param string $kind
    * @param int $line
    */
   private function track (array &$symbols, string $name, string $kind, int $line): void
   {
      if (!isset($symbols[$name])) {
         $symbols[$name] = ['kind' => $kind, 'lines' => []];
      }
      $symbols[$name]['lines'][] = $line;
   }

   /**
    * Report comments sitting inside the import block.
    *
    * `Formatter::format()` rewrites the whole block from the parsed import list, which is
    * the only way it can reorder them — so anything in that range that is not a `use`
    * has no defined place in the output and would simply vanish. There is no automatic
    * answer either: the import a comment describes may end up in a different section, and
    * a comment left next to the wrong statement misinforms worse than a missing fix does.
    * So the block is reported as un-rewritable and left for a human instead.
    *
    * @param array<int,mixed> $tokens
    * @param array{start:int,end:int} $range
    * @param array<int,Issue> $issues
    */
   private function survey (
      Tokens $Tokens,
      array $tokens,
      int $count,
      string $source,
      array $range,
      array &$issues
   ): void
   {
      // ?
      if ($range['start'] === -1 || $range['end'] === -1) {
         return;
      }

      // ! A trailing comment shares the last import's line, so the block ends at that
      //   line's break — not at the closing semicolon
      $break = strpos($source, "\n", $range['end']);
      $blockEnd = $break === false ? strlen($source) : $break;

      // ! Offsets are tracked inline — Tokens::locate() rescans from the
      //   start, which made this walk quadratic in the comments of a file
      $offset = 0;

      // @
      for ($i = 0; $i < $count; $i++) {
         $token = $tokens[$i];
         $at = $offset;
         /** @var string $content */
         $content = is_array($token) ? $token[1] : $token;
         $offset += strlen($content);

         // ? Past the block — nothing after it can sit inside it
         if ($at >= $blockEnd) {
            break;
         }
         if (is_array($token) === false) {
            continue;
         }
         if ($token[0] !== T_COMMENT && $token[0] !== T_DOC_COMMENT) {
            continue;
         }
         if ($at < $range['start']) {
            continue;
         }

         /** @var int $line */
         $line = $token[2];

         $issues[] = new Issue(
            type: 'comment_in_imports',
            symbol: '',
            kind: 'comment',
            line: $line,
            message: 'Comment inside the import block: reordering would drop it, '
               . 'so the block is left untouched — move the comment above or below it',
            offset: $at
         );

         // : One report per block is enough to explain why nothing was rewritten
         return;
      }
   }

   /**
    * Collect every identifier the file body could be naming.
    *
    * Deliberately over-inclusive. It records identifiers in ANY context, plus
    * every word inside comments and docblocks, instead of enumerating the
    * syntactic positions a name may legally appear in. Enumerating is the
    * fragile direction: the set this class already keeps for the missing-import
    * direction (`$usedSymbols`) covers calls, constants, `new`/`extends`/
    * `implements`/`instanceof` and static access — so it misses parameter and
    * return types, property types, `catch` clauses, attributes, trait `use` and
    * docblocks, and inverting it would report 2,310 live imports as unused out
    * of 2,334 candidates. Over-collecting fails the other way: it can only keep
    * an import that could have gone, which costs a missed cleanup rather than a
    * deletion of working code — and `--fix` writes the file.
    *
    * @param array<int,mixed> $tokens
    * @param array{start:int,end:int} $range
    *
    * @return array{names:array<string,bool>,exact:array<string,bool>}
    */
   private function sweep (array $tokens, int $count, array $range): array
   {
      $names = [];
      $exact = [];

      // ! Offsets are tracked inline — Tokens::locate() rescans from the start,
      //   which would make a whole-file walk quadratic
      $offset = 0;

      // @
      for ($i = 0; $i < $count; $i++) {
         $token = $tokens[$i];

         if (is_array($token) === false) {
            /** @var string $token */
            $offset += strlen($token);
            continue;
         }

         /** @var string $content */
         $content = $token[1];
         $at = $offset;
         $offset += strlen($content);

         // ? The import statements are not uses of themselves
         if ($range['start'] !== -1 && $at >= $range['start'] && $at < $range['end']) {
            continue;
         }

         // @ Comments and docblocks: every word counts. A type named only in a
         //   `@param`/`@var`/`@return` line is read by static analysis, so
         //   dropping its import breaks phpstan, not just the reader.
         if ($token[0] === T_COMMENT || $token[0] === T_DOC_COMMENT) {
            if (preg_match_all('/[A-Za-z_][A-Za-z0-9_]*/', $content, $matches) > 0) {
               foreach ($matches[0] as $word) {
                  $names[strtolower($word)] = true;
                  $exact[$word] = true;
               }
            }

            continue;
         }

         // @ A qualified name reaches its import through the FIRST segment:
         //   `extends Heading\Cookies` is a single token, so reading only
         //   T_STRING would report `Heading` as unused.
         if ($token[0] === T_NAME_QUALIFIED) {
            $head = explode('\\', $content)[0];
            $names[strtolower($head)] = true;
            $exact[$head] = true;

            continue;
         }

         // ? A fully qualified GLOBAL name (`\strlen`) is reported as a prefix
         //   to drop — once dropped it reaches the import, so the import is
         //   in use; a qualified one (`\Foo\Bar`) resolves on its own, and a
         //   relative one (`namespace\Foo`) never consults an import either
         if ($token[0] === T_NAME_FULLY_QUALIFIED) {
            $bare = substr($content, 1);
            if (str_contains($bare, '\\') === false) {
               $names[strtolower($bare)] = true;
               $exact[$bare] = true;
            }

            continue;
         }
         if ($token[0] !== T_STRING) {
            continue;
         }

         $names[strtolower($content)] = true;
         $exact[$content] = true;
      }

      // :
      return ['names' => $names, 'exact' => $exact];
   }

   /**
    * Report every import the body never names.
    *
    * @param array<int,array{symbol:string,kind:string,global:bool,line:int,alias:string}> $imports
    * @param array{names:array<string,bool>,exact:array<string,bool>} $references
    * @param array<int,Issue> $issues
    */
   private function prune (array $imports, array $references, array &$issues): void
   {
      foreach ($imports as $import) {
         $alias = $import['alias'];

         // ? Constants are the one kind PHP resolves case-sensitively
         $referenced = $import['kind'] === 'const'
            ? isset($references['exact'][$alias])
            : isset($references['names'][strtolower($alias)]);

         if ($referenced === true) {
            continue;
         }

         $label = match ($import['kind']) {
            'function' => "use function {$import['symbol']};",
            'const'    => "use const {$import['symbol']};",
            default    => "use {$import['symbol']};",
         };

         $issues[] = new Issue(
            type: 'unused_import',
            symbol: $import['symbol'],
            kind: $import['kind'],
            line: $import['line'],
            message: "Unused import: {$label}"
         );
      }
   }

   /**
    * Count the namespace DECLARATIONS of a file — the keyword is also a
    * legal argument label (`f(namespace: 'x')`), which names nothing.
    *
    * @param array<int,mixed> $tokens
    * @param int $count
    */
   private function count (array $tokens, int $count): int
   {
      $declared = 0;
      for ($i = 0; $i < $count; $i++) {
         $token = $tokens[$i];
         if (is_array($token) && $token[0] === T_NAMESPACE && $this->check($tokens, $count, $i)) {
            $declared++;
         }
      }

      // :
      return $declared;
   }

   /**
    * Whether the `namespace` token at a position DECLARES a namespace.
    *
    * The keyword is also a legal argument label (`f(namespace: 'x')`), a
    * legal method name (`function namespace ()`) and a legal constant name
    * (`Foo::namespace`); only one followed by a name — or by `{`, the global
    * block — declares.
    *
    * @param array<int,mixed> $tokens
    * @param int $count
    * @param int $i The position of the T_NAMESPACE token
    */
   private function check (array $tokens, int $count, int $i): bool
   {
      $following = $tokens[$this->advance($tokens, $i, $count)] ?? null;

      // :
      return $following === '{'
         || (is_array($following) && in_array($following[0], [T_STRING, T_NAME_QUALIFIED], true));
   }

   /**
    * Whether a name followed by `=` sits in a `const` statement — the type
    * tokens, an earlier `NAME = value,` of a list, or nothing at all may lie
    * between the keyword and the name.
    *
    * @param array<int,mixed> $tokens
    * @param int $i The position of the name
    */
   private function trace (array $tokens, int $i): bool
   {
      $depth = 0;
      for ($j = $i - 1; $j >= 0; $j--) {
         $token = $tokens[$j];
         if ($token === ')') {
            $depth++;
            continue;
         }
         if ($token === '(') {
            $depth--;
            continue;
         }
         // ? The statement boundary: no `const` was found on the way
         if ($depth === 0 && ($token === ';' || $token === '{' || $token === '}')) {
            return false;
         }
         if (is_array($token) && $token[0] === T_CONST) {
            return true;
         }
      }

      // :
      return false;
   }

   /**
    * Validate import ordering and generate issues.
    *
    * @param array<int,array{symbol:string,kind:string,global:bool,line:int,alias:string}> $imports
    * @param array<int,Issue> $issues
    */
   private function validate (array &$imports, array &$issues): void
   {
      if (count($imports) < 2) {
         return;
      }

      // @ Define expected order: const → function → class
      $kindOrder = ['const' => 0, 'function' => 1, 'class' => 2];

      $prevKindIndex = -1;
      $prevGlobal = true;
      $prevSymbol = '';
      $prevKind = '';
      // ! Once a namespaced import was seen, every later global one is misplaced
      $namespaced = false;

      foreach ($imports as $import) {
         $kindIndex = $kindOrder[$import['kind']];
         $isGlobal = $import['global'];

         // @ The global block comes first, whole: a global import after any
         //   namespaced one is out of place whatever its kind
         if ($isGlobal && $namespaced) {
            $issues[] = new Issue(
               type: 'global_not_first',
               symbol: $import['symbol'],
               kind: $import['kind'],
               line: $import['line'],
               message: "Global import should come before namespaced: {$import['symbol']}"
            );
         }
         if ($isGlobal === false) {
            $namespaced = true;
         }

         // @ Kind tracking restarts when crossing the global/namespaced boundary:
         //   each block orders const → function → class on its own
         if ($isGlobal !== $prevGlobal) {
            $prevKindIndex = -1;
            $prevSymbol = '';
         }

         // @ Check kind ordering (const before function before class), within same group
         if ($kindIndex < $prevKindIndex) {
            $issues[] = new Issue(
               type: 'wrong_order',
               symbol: $import['symbol'],
               kind: $import['kind'],
               line: $import['line'],
               message: "Wrong import order: use {$import['kind']} should come before use {$prevKind}"
            );
         }

         // @ Within same kind and same global/namespaced group: alphabetical
         if ($kindIndex === $prevKindIndex && $isGlobal === $prevGlobal && $prevSymbol !== '') {
            if (strcasecmp($import['symbol'], $prevSymbol) < 0) {
               $issues[] = new Issue(
                  type: 'not_alphabetical',
                  symbol: $import['symbol'],
                  kind: $import['kind'],
                  line: $import['line'],
                  message: "Import not alphabetically ordered: {$import['symbol']} should come before {$prevSymbol}"
               );
            }
         }

         $prevKindIndex = $kindIndex;
         $prevGlobal = $isGlobal;
         $prevSymbol = $import['symbol'];
         $prevKind = $import['kind'];
      }
   }
}
