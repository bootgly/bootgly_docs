<?php

require __DIR__ . '/../../../../../../autoload.php';

use Bootgly\ABI\Data\__String\Tokens\Highlighter;

#require '../Highlighter.php';

$Highligher = new Highlighter;

$tokenized = $Highligher->highlight(
   source: <<<'PHP'
   <?php
   // Comment
   $s = 'test1';
   $n = 123;
   $c = \PHP_SAPI
   $a = [1, 2, 3];

   assert($s === 'test1', \Exception('Foo not matched'));

   /*
   * Multiline comment
   */
   PHP,
   marked_line: 5
);

echo($tokenized);