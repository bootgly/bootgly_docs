<?php

// Save the current cursor position
echo "\033[s";

// Print "Position 1:" and store the current cursor position in $pos1
echo "Position 1:";
echo "\033[6n";
$pos = '';
while (true) {
    $char = fgetc(STDIN);
    if ($char === 'R') {
        break;
    }
    $pos .= $char;
}
list($row, $col) = explode(';', substr($pos, 2));
$pos1 = "\033[" . ($row - 1) . ";1H";

// Move the cursor to line 10, column 5 and print "Position 2:"
echo "\033[10;5HPosition 2:";
$pos2 = "\033[10;5H";

sleep(5);

// Restore the position of "Position 2:"
echo $pos2 . "Position 2 restored\n";

// Restore the position of "Position 1:"
echo $pos1 . "Position 1 restored\n";
