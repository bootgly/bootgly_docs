<?php
// Print the message "Position saved" on the screen and save the current cursor position
echo "Position saved here >\033[s<";

// Print an additional message
echo "This is an example of an additional message...";

// Simulate a 3 second pause
sleep(3);

// Return to the saved position and print the message "Position restored" on the screen
echo "\033[uPosition restored";

echo "\n";
