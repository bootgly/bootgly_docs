<?php
$progress = 0;

$n = $argv[1] ?? '';

while ($progress <= 100) {
   // Try to comment this line or change `<n>` in the <n>G
   echo "\033[{$n}G"; // @ Move the cursor to the first column (if <n> = 1, 0 or '') of current line
   echo "\033[2d";

   echo "\033[1E";

   // @ Write the progress bar in the current line
   echo "[" . str_repeat("=", $progress / 5) . str_repeat(" ", 20 - $progress / 5) . "] " . $progress . "%";

   usleep(100000); // @ Wait 0.1 seconds

   $progress += 5; // @ Increase the progress bar unit
}

echo "\n";
