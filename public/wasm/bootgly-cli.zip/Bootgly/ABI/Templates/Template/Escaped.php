<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Bootgly and contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ABI\Templates\Template;


use const PHP_EOL;
use function is_string;
use function preg_replace;
use function preg_replace_callback_array;
use function str_repeat;
use function strlen;

use Bootgly\ABI\Code\__String\Escapeable;
use Bootgly\ABI\Code\__String\Escapeable\Cursor\Positionable;
use Bootgly\ABI\Code\__String\Escapeable\Cursor\Shapeable;
use Bootgly\ABI\Code\__String\Escapeable\Cursor\Visualizable;
use Bootgly\ABI\Code\__String\Escapeable\Text\Formattable;
use Bootgly\ABI\Code\__String\Escapeable\Text\Modifiable;
use Bootgly\ABI\Code\__String\Escapeable\Viewport\Scrollable;
use Bootgly\ABI\Code\__String\Theme;
use Bootgly\ABI\Resources;


class Escaped
{
   use Escapeable;
   use Positionable;
   use Shapeable;
   use Visualizable;
   use Formattable;
   use Modifiable;
   use Scrollable;
   use Resources;

   // * Config
   // ...

   // * Data
   /** @var array<string, callable> */
   protected static array $directives = [];

   // * Metadata
   /** @var array<string> */
   protected static array $names = [];


   public static function boot (): void
   {
      self::$directives = [
         '/@(#[a-zA-Z]+):(\s?)/m' => function ($matches) {
            $color = match ($matches[1]) {
               '#black' => self::_BLACK_FOREGROUND,
               '#red' => self::_RED_FOREGROUND,
               '#green' => self::_GREEN_FOREGROUND,
               '#yellow' => self::_YELLOW_FOREGROUND,
               '#blue' => self::_BLUE_FOREGROUND,
               '#magenta' => self::_MAGENTA_FOREGROUND,
               '#cyan' => self::_CYAN_FOREGROUND,
               '#white' => self::_WHITE_FOREGROUND,
      
               '#Black', '#BLACK' => self::_BLACK_BRIGHT_FOREGROUND,
               '#Red', '#RED' => self::_RED_BRIGHT_FOREGROUND,
               '#Green', '#GREEN' => self::_GREEN_BRIGHT_FOREGROUND,
               '#Yellow', '#YELLOW' => self::_YELLOW_BRIGHT_FOREGROUND,
               '#Blue', '#BLUE' => self::_BLUE_BRIGHT_FOREGROUND,
               '#Magenta', '#MAGENTA' => self::_MAGENTA_BRIGHT_FOREGROUND,
               '#Cyan', '#CYAN' => self::_CYAN_BRIGHT_FOREGROUND,
               '#White', '#WHITE' => self::_WHITE_BRIGHT_FOREGROUND,
      
               default => self::_DEFAULT_FOREGROUND
            };

            return self::wrap($color);
         },

         '/@(![a-zA-Z]+):(\s?)/m' => function ($matches) {
            $color = match ($matches[1]) {
               '!black' => self::_BLACK_BACKGROUND,
               '!red' => self::_RED_BACKGROUND,
               '!green' => self::_GREEN_BACKGROUND,
               '!yellow' => self::_YELLOW_BACKGROUND,
               '!blue' => self::_BLUE_BACKGROUND,
               '!magenta' => self::_MAGENTA_BACKGROUND,
               '!cyan' => self::_CYAN_BACKGROUND,
               '!white' => self::_WHITE_BACKGROUND,

               '!Black', '!BLACK' => self::_BLACK_BRIGHT_BACKGROUND,
               '!Red', '!RED' => self::_RED_BRIGHT_BACKGROUND,
               '!Green', '!GREEN' => self::_GREEN_BRIGHT_BACKGROUND,
               '!Yellow', '!YELLOW' => self::_YELLOW_BRIGHT_BACKGROUND,
               '!Blue', '!BLUE' => self::_BLUE_BRIGHT_BACKGROUND,
               '!Magenta', '!MAGENTA' => self::_MAGENTA_BRIGHT_BACKGROUND,
               '!Cyan', '!CYAN' => self::_CYAN_BRIGHT_BACKGROUND,
               '!White', '!WHITE' => self::_WHITE_BRIGHT_BACKGROUND,

               default => self::_DEFAULT_BACKGROUND
            };

            return self::wrap($color);
         },

         '/@(\\\\+);/m' => function ($matches) { // DEPRECATED
            if ($matches[0]) {
               return str_repeat(PHP_EOL, strlen($matches[1]));
            }
         },
         '/@(\.+);/m' => function ($matches) {
            if ($matches[0]) {
               return str_repeat(PHP_EOL, strlen($matches[1]));
            }
         },
   
         '/@(:[a-z]+):/m' => function ($matches) {
            // # Semantic color — resolved through the active UI Theme (dark/light/mono).
            $key = match ($matches[1]) {
               ':s', ':success' => 'success',
               ':d', ':debug'   => 'debug',
               ':i', ':info'    => 'info',
               ':n', ':notice'  => 'notice',
               ':w', ':warning' => 'warning',
               ':e', ':error'   => 'error',

               default => null
            };

            // ?: Unknown semantic token — keep the default foreground
            if ($key === null) {
               return self::wrap(self::_DEFAULT_FOREGROUND);
            }

            return Theme::$Current->open($key);
         },
   
         '/@([@*~_-]):[\s]?/m' => function ($matches) {
            $style = match ($matches[1]) {
               '@' => self::_BLINK_STYLE,
      
               '*' => self::_BOLD_STYLE,
               '~' => self::_ITALIC_STYLE,
               '_' => self::_UNDERLINE_STYLE,
               '-' => self::_STRIKE_STYLE,
      
               default => ''
            };
      
            return self::wrap($style);
         },
   
         '/\s?@(;)|([*~_-])@/m' => function ($matches) {
            return self::_RESET_FORMAT;
         }
      ];
   }

   /**
    * Render the Output markup (`@#red:`, `@*:`, `@;`, `@.;`) of text this program wrote.
    *
    * Every other byte is returned as it is — control characters included. Not
    * a sanitizer: text this program did not write — a peer's reply, a file
    * name, a remote's message — goes through
    * `Escaped::scrub(Controls::escape(mb_scrub($text, 'UTF-8')))` first.
    *
    * @param string $message The text with its markup.
    *
    * @return string The text with SGR sequences in place of the markup.
    */
   public static function render (string $message): string
   {
      $message = preg_replace_callback_array(self::$directives, $message);

      if (!is_string($message)) {
         return '';
      }

      return $message;
   }

   /**
    * Defuse the markup in a text this program did not author, so `render()` shows it as is.
    *
    * Every directive is an `@` followed by one of `#!\.:;@*~_-`, or one of `*~_-` followed by
    * `@` — never an `@` followed by a letter or a digit. So each `@` that is not followed by a
    * letter, a digit or a non-ASCII byte goes, and so does each `@` right after `*`, `~`, `_`,
    * `-`; `user@example.com` survives. Control characters are left to `Controls::escape()`.
    *
    * A scrubbed value stays inert only on its own: an `@` written right before it
    * (`"{$user}@{$host}"` with a host of `.;`) rebuilds a directive.
    *
    * @param string $text The text to defuse.
    *
    * @return string The text without markup introducers.
    */
   public static function scrub (string $text): string
   {
      // @@ To a FIXED POINT: one pass is not closed under its own deletions —
      //   in `-@@x`, dropping the first `@` leaves the second one after `-`,
      //   which is the reset directive. Each pass shortens the text or ends
      //   the loop.
      do {
         $previous = $text;
         $text = preg_replace('/(?<=[*~_-])@|@(?![A-Za-z0-9\x80-\xFF])/', '', $text) ?? '';
      }
      while ($text !== $previous);

      // :
      return $text;
   }
}

Escaped::boot();
