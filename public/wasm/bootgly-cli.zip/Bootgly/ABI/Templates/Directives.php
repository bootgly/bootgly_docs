<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Rodrigo de Araujo Vieira Tecnologia da Informação LTDA and Bootgly contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ABI\Templates;


use function implode;
use function is_array;
use function is_string;
use Closure;

use const Bootgly\ABI\BOOTSTRAP_FILENAME;
use Bootgly\ABI\Data\__String\Path;
use Bootgly\ABI\Resources;


class Directives
{
   use Resources;


   // * Config
   // ...

   // * Data
   /** @var array<string,Closure> */
   protected array $directives;

   // * Metadata
   /** @var array<string> */
   protected array $names;
   // @ Regex
   protected string $tokens;


   public function __construct ()
   {
      $resource = __DIR__ . '/Template/directives/';
      $bootstrap = require($resource . BOOTSTRAP_FILENAME);

      $directives = $bootstrap['directives'];
      foreach ($directives as $name => $value) {
         // @ Register directive name
         if (is_string($name) === true) {
            $this->names[] = $name;
         }

         // @ Set directive value
         $directive = [];
         if (is_string($value) === true) {
            $filename = Path::normalize($value);

            $directive = require($resource . $filename . '.directive.php');
         }
         else if (is_array($value) === true) {
            $directive = $value;
         }

         foreach ($directive as $pattern => $Closure) {
            $this->directives[$pattern] = $Closure;
         }
      }

      $this->tokens = implode('|', $this->names);
   }
   public function __get (string $name): mixed
   {
      switch ($name) {
         // * Data
         case 'directives':
            return $this->directives;

         // * Metadata
         case 'names':
            return $this->names;
         // @ Regex
         case 'tokens':
            return $this->tokens;

         default:
            return null;
      }
   }

   public function extend (string $pattern, Closure $Callback, null|string $name = null): void
   {
      if ($name) {
         $this->names[] = $name;
      }

      $this->directives[$pattern] ??= $Callback;
   }
}
