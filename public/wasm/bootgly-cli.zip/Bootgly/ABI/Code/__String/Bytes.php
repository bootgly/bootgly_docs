<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Rodrigo de Araujo Vieira Tecnologia da Informação LTDA and Bootgly contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ABI\Code\__String;


use function count;
use function floor;
use function log;
use function max;
use function min;
use function pow;
use function round;


class Bytes
{
   public static function format (float|int $bytes, int $precision = 2): string
   {
      $units = ['B', 'KB', 'MB', 'GB', 'TB'];

      $bytes = (float) max($bytes, 0);
      $pow = (int) min(
         floor(($bytes ? log($bytes): 0) / log(1024)),
         count($units) - 1
      );

      // Uncomment one of the following alternatives
      $bytes /= pow(1024, $pow);
      // $bytes /= (1 << (10 * $pow));

      return round($bytes, $precision) . ' ' . $units[$pow];
   }
}
