<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Bootgly and contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ABI\Code\__String\Markdown;


/**
 * Block-level Markdown node types.
 */
enum Blocks
{
   case Heading;
   case Paragraph;
   case Fence;
   case Quote;
   case List;
   case Item;
   case Table;
   case Row;
   case Cell;
   case Rule;
}
