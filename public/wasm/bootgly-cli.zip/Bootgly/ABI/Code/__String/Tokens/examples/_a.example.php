<?php

require __DIR__ . '/../../../../../../autoboot.php';

use Bootgly\ABI\Code\__String\Tokens\Highlighter;

$Highlighter = new Highlighter;

// @ Guttered (line numbers + marked line) — as used by ABI/Debugging
$highlighted = $Highlighter->highlight(
   source: <<<'PHP'
   <?php
   // Comment
   $s = 'test1';
   $n = 123;
   $c = \PHP_SAPI
   $a = [1, 2, 3];

   assert($s === 'test1', \Exception('Foo not matched'));

   /*
   * Multiline comment
   */
   PHP,
   marked_line: 5
);

echo $highlighted, "\n";

// @ Gutterless — bare colored lines (as used by CLI UI fences)
$highlighted = $Highlighter->highlight(
   source: <<<'PHP'
   $greeting = 'Hello';
   $count = 3;
   echo "{$greeting} x {$count}";
   PHP,
   gutter: false
);

echo $highlighted, "\n";
