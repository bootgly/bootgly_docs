<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Rodrigo de Araujo Vieira Tecnologia da Informação LTDA and Bootgly contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ABI\IO\FS\File;


use function explode;
use function mime_content_type;


class MIME
{
   // * Data
   public readonly string $type;
   // * Metadata
   public readonly string $format;
   public readonly string $subtype;


   public function __construct (string $filename)
   {
      $mime_content_type = mime_content_type($filename) ?: "";

      [$format, $subtype] = explode("/", $mime_content_type);

      // * Data
      $this->type = $mime_content_type;
      // * Metadata
      $this->format = $format;
      $this->subtype = $subtype;
   }
   public function __toString ()
   {
      return $this->type;
   }
}
