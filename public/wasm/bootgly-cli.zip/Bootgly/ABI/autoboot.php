<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Bootgly and contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

// @ Local namespace
namespace Bootgly\ABI {

   use Bootgly\ABI\Debugging\Data\Throwables\Errors;
   use Bootgly\ABI\Debugging\Data\Throwables\Exceptions;

   use Bootgly\ABI\Debugging\Shutdown;


   // ! Bootstrap filename (canonical directory-entry file — see Bootgly One-Way)
   const BOOTSTRAP_FILENAME = 'autoboot.php';

   // @ Debugging\Data\Errors
   \restore_error_handler();
   \set_error_handler(
      callback: Errors::collect(...),
      error_levels: E_ALL
   );

   // @ Debugging\Data\Exceptions
   \restore_exception_handler();
   \set_exception_handler(
      callback: Exceptions::handle(...) // @phpstan-ignore-line
   );

   // @ Debugging\Shutdown
   \register_shutdown_function(
      callback: Shutdown::debug(...)
   );

   // @ IO\FS
   // functions
   if (\function_exists('\Bootgly\ABI\copy_recursively') === false) {
      function copy_recursively (string $source, string $destination): void
      {
         // ? A symlink is copied AS the link, and tested FIRST: is_dir() and
         //   is_file() both follow it, so otherwise a link becomes a regular
         //   file (git: a 120000 -> 100644 typechange) or a duplicated
         //   directory tree — and one pointing at an ancestor is walked until
         //   the kernel's link limit stops it. remove_recursively() already
         //   draws this line.
         if (\is_link($source) === true) {
            $target = \readlink($source);

            if ($target !== false) {
               \symlink($target, $destination);
            }
         }
         else if (\is_dir($source) === true) {
            // ? Layered copies land on a destination an earlier source made
            if (\is_dir($destination) === false) {
               \mkdir($destination);
            }

            $paths = \scandir($source);
            if ($paths === false) {
               return;
            }

            foreach ($paths as $path) {
               if ($path !== '.' && $path !== '..') {
                  copy_recursively("$source/$path", "$destination/$path");
               }
            }
         }
         else if (\is_file($source) === true) {
            // regular files only — sockets, FIFOs and devices are not copyable
            \copy($source, $destination);

            // ! PHP's copy() drops the mode: without it a kept `.git` (hooks,
            //   packed refs) reports spurious 100755 -> 100644 dirt. The umask
            //   still governs who else may read or write the copy.
            $mode = \fileperms($source);
            if ($mode !== false) {
               \chmod($destination, $mode & 0777 & ~\umask());
            }
         }
      }
   }
   if (\function_exists('\Bootgly\ABI\remove_recursively') === false) {
      function remove_recursively (string $target): void
      {
         // ? A symlink is removed as the link, never followed into its target;
         //   any other non-directory entry (a FIFO, a socket, a device node)
         //   is unlinked too — a tree is removed whole or not at all
         if (\is_link($target) === true || (\file_exists($target) === true && \is_dir($target) === false)) {
            \unlink($target);

            return;
         }
         if (\is_dir($target) === false) {
            return;
         }

         $paths = \scandir($target);
         if ($paths !== false) {
            foreach ($paths as $path) {
               if ($path !== '.' && $path !== '..') {
                  remove_recursively("$target/$path");
               }
            }
         }

         \rmdir($target);
      }
   }
}

// @ Global namespace
namespace {

   use Bootgly\ABI\Code\__String;
   use Bootgly\ABI\Debugging\Backtrace;
   use Bootgly\ABI\Debugging\Data\Vars;

   // @ Debugging\Data\Vars
   // functions
   if (\function_exists('dump') === false) {
      function dump (mixed ...$vars): void
      {
         // * Data
         // + Backtrace
         Vars::$Backtrace = new Backtrace;

         Vars::debug(...$vars);
      }
   }
   if (\function_exists('dd') === false) { // dd = dump and die
      function dd (mixed ...$vars): void
      {
         // * Config
         Vars::$exit = true;
         Vars::$debug = true;
         // * Data
         // + Backtrace
         Vars::$Backtrace = new Backtrace;

         Vars::debug(...$vars);
      }
   }

   /**
    * Polyfills mb_* functions (used in Bootgly only)
    *
    * @author Fabien Potencier and Symfony contributors
    * @link https://github.com/symfony/polyfill-mbstring
    */
   // mb_strlen
   if (!\function_exists('mb_strlen')) {
      function mb_strlen(string $string, string|null $encoding = 'UTF-8'): int|false
      {
         $encoding = __String::encoding($encoding);

         if ($encoding === 'CP850' || $encoding === 'ASCII') {
            return \strlen($string);
         }

         // ? Runtimes without ext-iconv (e.g. WASM builds): count code points with PCRE
         if (!\function_exists('iconv_strlen')) {
            if ($encoding === 'UTF-8' && \preg_match_all('/./su', $string, $matches) !== false) {
               return \count($matches[0]);
            }

            return \strlen($string);
         }

         return @\iconv_strlen($string, $encoding);
      }
   }

   // mb_convert_case
   if (!\function_exists('mb_convert_case')) {
      function mb_convert_case(string $string, int $mode, string|null $encoding = 'UTF-8'): string
      {
         if ($string === '') {
            return '';
         }

         $encoding = __String::encoding($encoding);

         if ($encoding === 'UTF-8') {
            $encoding = null;
            if (!\preg_match('//u', $string)) {
               $string = \function_exists('iconv')
                  ? @\iconv('UTF-8', 'UTF-8//IGNORE', $string)
                  : false;
            }
         }
         else {
            // ? Non-UTF-8 conversion requires ext-iconv
            $string = \function_exists('iconv')
               ? \iconv($encoding, 'UTF-8//IGNORE', $string)
               : false;
         }

         if ($string === false) {
            return '';
         }

         if ($mode === 2) {
            static $titleRegexp = null;

            if ($titleRegexp === null) {
               $titleRegexp = __String::mapping('titleCaseRegexp');
            }

            $string = \preg_replace_callback($titleRegexp, function (array $string): string {
               $uppercase = \mb_convert_case($string[1], 0, 'UTF-8');
               $lowercase = \mb_convert_case($string[2], 1, 'UTF-8');

               return "{$uppercase}{$lowercase}";
            }, (string) $string);
         }
         else {
            if ($mode === 0) {
               static $upper = null;
               if ($upper === null) {
                  $upper = __String::mapping('upperCase');
               }
               $map = $upper;
            }
            else {
               if ($mode === 3) {
                  static $caseFolding = null;
                  if ($caseFolding === null) {
                     $caseFolding = __String::mapping('caseFolding');
                  }
                  $string = \strtr($string, $caseFolding);
               }

               static $lower = null;
               if ($lower === null) {
                  $lower = __String::mapping('lowerCase');
               }
               $map = $lower;
            }

            static $ulenMask = ["\xC0" => 2, "\xD0" => 2, "\xE0" => 3, "\xF0" => 4];

            $i = 0;
            $len = \strlen($string);

            while ($i < $len) {
               $ulen = $string[$i] < "\x80" ? 1 : $ulenMask[$string[$i] & "\xF0"];
               $uchr = \substr($string, $i, $ulen);
               $i += $ulen;

               if (isSet($map[$uchr])) {
                  $uchr = $map[$uchr];
                  $nlen = \strlen($uchr);

                  if ($nlen === $ulen) {
                     $nlen = $i;

                     do {
                        $string[--$nlen] = $uchr[--$ulen];
                     }
                     while ($ulen);
                  }
                  else {
                     $string = \substr_replace($string, $uchr, $i - $ulen, $ulen);
                     $len += $nlen - $ulen;
                     $i += $nlen - $ulen;
                  }
               }
            }
         }

         if (!is_string($string)) {
            return '';
         }

         if ($encoding === null) {
            return $string;
         }

         // @ Encode (requires ext-iconv; UTF-8 targets return above)
         if (!\function_exists('iconv')) {
            return $string;
         }

         return \iconv(
            'UTF-8',
            "{$encoding}//IGNORE",
            $string
         ) ?: '';
      }
   }

   // mb_strtoupper
   if (!function_exists('mb_strtoupper')) {
      function mb_strtoupper(string $string, string|null $encoding = 'UTF-8'): string
      {
         return mb_convert_case($string, 0, $encoding);
      }
   }

   // mb_strtolower
   if (!function_exists('mb_strtolower')) {
      function mb_strtolower(string $string, string|null $encoding = 'UTF-8'): string
      {
         return mb_convert_case($string, 1, $encoding);
      }
   }

   // mb_substr
   if (!function_exists('mb_substr')) {
      function mb_substr(string $string, int $start, int|null $length = null, string|null $encoding = 'UTF-8'): string
      {
         $encoding = __String::encoding($encoding);
         if ('CP850' === $encoding || 'ASCII' === $encoding) {
            return (string) \substr($string, $start, null === $length ? 2147483647 : $length);
         }

         // ? Runtimes without ext-iconv (e.g. WASM builds): slice code points with PCRE
         if (!\function_exists('iconv_substr')) {
            if ($encoding === 'UTF-8' && \preg_match_all('/./su', $string, $matches) !== false) {
               $sliced = \array_slice($matches[0], $start, $length);

               return \implode('', $sliced);
            }

            return (string) \substr($string, $start, $length ?? 2147483647);
         }

         if ($start < 0) {
            $start = \iconv_strlen($string, $encoding) + $start;

            if ($start < 0) {
               $start = 0;
            }
         }

         if ($length === null) {
            $length = 2147483647;
         }
         elseif ($length < 0) {
            $length = \iconv_strlen($string, $encoding) + $length - $start;

            if ($length < 0) {
               return '';
            }
         }

         return (string) \iconv_substr($string, $start, $length, $encoding);
      }
   }

   // mb_str_split
   if (!function_exists('mb_str_split')) {
      /**
       * @return array<int,string>
       */
      function mb_str_split(string $string, int $length = 1, string|null $encoding = 'UTF-8'): array
      {
         // ? Split into code points with PCRE (UTF-8)
         $chars = \preg_split('//u', $string, -1, \PREG_SPLIT_NO_EMPTY);
         if ($chars === false) {
            $chars = \str_split($string);
         }

         if ($length <= 1) {
            return $chars;
         }

         return \array_map('implode', \array_chunk($chars, $length));
      }
   }

   // mb_stripos
   if (!function_exists('mb_stripos')) {
      function mb_stripos(string $haystack, string $needle, int $offset = 0, string|null $encoding = 'UTF-8'): int|false
      {
         // @ Case-fold both strings (map-based folding preserves character counts)
         $haystack = mb_strtolower($haystack, $encoding);
         $needle = mb_strtolower($needle, $encoding);

         // ? Negative offsets count from the end
         if ($offset < 0) {
            $offset = \max(0, (int) mb_strlen($haystack, $encoding) + $offset);
         }

         // @ UTF-8 is self-synchronizing — a byte-level match always lands on a character boundary
         $bytes = \strlen(mb_substr($haystack, 0, $offset, $encoding));
         $position = \strpos($haystack, $needle, $bytes);

         if ($position === false) {
            return false;
         }

         // : Character position
         return mb_strlen(\substr($haystack, 0, $position), $encoding);
      }
   }

   // mb_strwidth
   if (!function_exists('mb_strwidth')) {
      function mb_strwidth(string $string, string|null $encoding = 'UTF-8'): int
      {
         // @ East Asian Wide + Fullwidth ranges take two columns; everything else takes one
         $wide = 0;
         $string = (string) \preg_replace(
            '/[\x{1100}-\x{115F}\x{2E80}-\x{303E}\x{3041}-\x{33FF}\x{3400}-\x{4DBF}\x{4E00}-\x{9FFF}\x{A000}-\x{A4CF}\x{A960}-\x{A97F}\x{AC00}-\x{D7A3}\x{F900}-\x{FAFF}\x{FE10}-\x{FE19}\x{FE30}-\x{FE6F}\x{FF00}-\x{FF60}\x{FFE0}-\x{FFE6}\x{20000}-\x{2FFFD}\x{30000}-\x{3FFFD}]/u',
            '',
            $string,
            -1,
            $wide
         );

         // : Two columns per wide character + one per remaining character
         return ($wide << 1) + (int) mb_strlen($string, $encoding);
      }
   }

   // mb_strimwidth
   if (!function_exists('mb_strimwidth')) {
      function mb_strimwidth(string $string, int $start, int $width, string $trim_marker = '', string|null $encoding = 'UTF-8'): string
      {
         // ! Slice from the character offset
         $string = mb_substr($string, $start, null, $encoding);

         // ? The visible width already fits
         if (mb_strwidth($string, $encoding) <= $width) {
            return $string;
         }

         // @ Reserve columns for the trim marker, then fill character by character
         $width -= mb_strwidth($trim_marker, $encoding);

         $output = '';
         $columns = 0;

         foreach (mb_str_split($string, 1, $encoding) as $character) {
            $columns += mb_strwidth($character, $encoding);

            if ($columns > $width) {
               break;
            }

            $output .= $character;
         }

         // : Truncated string with the trim marker appended
         return "{$output}{$trim_marker}";
      }
   }

   // mb_str_pad
   if (!function_exists('mb_str_pad')) {
      function mb_str_pad(string $string, int $length, string $pad_string = ' ', int $pad_type = \STR_PAD_RIGHT, string|null $encoding = 'UTF-8'): string
      {
         // ? Nothing to pad
         $missing = $length - (int) mb_strlen($string, $encoding);
         if ($missing <= 0 || $pad_string === '') {
            return $string;
         }

         // ! Characters per side (STR_PAD_BOTH leaves the extra one on the right)
         $left = match ($pad_type) {
            \STR_PAD_LEFT => $missing,
            \STR_PAD_BOTH => \intdiv($missing, 2),
            default => 0
         };

         // @ Repeat the pad string and cut each side to its exact character count
         $unit = \max(1, (int) mb_strlen($pad_string, $encoding));
         $padding = \str_repeat($pad_string, (int) \ceil($missing / $unit));

         // : Left padding + string + right padding
         return mb_substr($padding, 0, $left, $encoding)
            . $string
            . mb_substr($padding, 0, $missing - $left, $encoding);
      }
   }

   // mb_chr
   if (!function_exists('mb_chr')) {
      function mb_chr(int $codepoint, string|null $encoding = 'UTF-8'): string|false
      {
         // ? UTF-8 encode by codepoint range (1–4 bytes)
         if ($codepoint < 0 || $codepoint > 0x10FFFF || ($codepoint >= 0xD800 && $codepoint <= 0xDFFF)) {
            return false;
         }
         if ($codepoint < 0x80) {
            return \chr($codepoint);
         }
         if ($codepoint < 0x800) {
            return \chr(0xC0 | ($codepoint >> 6)) . \chr(0x80 | ($codepoint & 0x3F));
         }
         if ($codepoint < 0x10000) {
            return \chr(0xE0 | ($codepoint >> 12))
               . \chr(0x80 | (($codepoint >> 6) & 0x3F))
               . \chr(0x80 | ($codepoint & 0x3F));
         }

         return \chr(0xF0 | ($codepoint >> 18))
            . \chr(0x80 | (($codepoint >> 12) & 0x3F))
            . \chr(0x80 | (($codepoint >> 6) & 0x3F))
            . \chr(0x80 | ($codepoint & 0x3F));
      }
   }

   // mb_scrub
   if (!function_exists('mb_scrub')) {
      function mb_scrub(string $string, string|null $encoding = null): string
      {
         // ? Well-formed UTF-8 — or another encoding, which has no converter without ext-mbstring
         if (__String::encoding($encoding) !== 'UTF-8' || \preg_match('//u', $string) === 1) {
            return $string;
         }

         // : Every maximal ill-formed subsequence becomes one `?`, as ext-mbstring writes it
         return (string) \preg_replace(
            '/(?:[\x00-\x7F]|[\xC2-\xDF][\x80-\xBF]|\xE0[\xA0-\xBF][\x80-\xBF]|[\xE1-\xEC\xEE\xEF][\x80-\xBF]{2}'
            . '|\xED[\x80-\x9F][\x80-\xBF]|\xF0[\x90-\xBF][\x80-\xBF]{2}|[\xF1-\xF3][\x80-\xBF]{3}|\xF4[\x80-\x8F][\x80-\xBF]{2})'
            . '(*SKIP)(*FAIL)'
            . '|\xE0[\xA0-\xBF]?|[\xE1-\xEC\xEE\xEF][\x80-\xBF]?|\xED[\x80-\x9F]?'
            . '|\xF0(?:[\x90-\xBF][\x80-\xBF]?)?|[\xF1-\xF3](?:[\x80-\xBF][\x80-\xBF]?)?|\xF4(?:[\x80-\x8F][\x80-\xBF]?)?'
            . '|[\x80-\xFF]/',
            '?',
            $string
         );
      }
   }
}
