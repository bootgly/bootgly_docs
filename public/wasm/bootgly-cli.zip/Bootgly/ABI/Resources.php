<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Bootgly and contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\ABI;


use function end;
use function explode;
use function strtolower;


trait Resources
{
   // * Metadata
   protected string $resource {
      get {
         // ?:
         if ($this->resource ?? false) {
            return $this->resource;
         }

         // @
         $parent = static::class;
         $parts = explode('\\', $parent);

         $class = end($parts);
         $resource = strtolower($class);

         // !:
         return $this->resource = $resource;
      }
   }
}
