<?php

require __DIR__ . '/../../../../../autoload.php';


use Bootgly\ABI\Debugging\Data;


Data::debug(new \Error('error'), new \Exception('exception'), 't');
