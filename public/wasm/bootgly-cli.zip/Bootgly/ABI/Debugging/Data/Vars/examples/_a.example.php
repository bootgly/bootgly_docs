<?php

require __DIR__ . '/../../../../../../autoload.php';

function test () {}

dump([
   'a' => 1,
   'b' => 'abc',
   'c' => null,
   'd' => true,
   'e' => 1.2,
   'f' => (object) ['test' => 1, 'test2' => 2],
   'g' => test(...),
   'h' => new stdClass(),
   'i' => [
      'f' => 1,
      'g' => 'abc',
      null,
      true,
      1.2,
      (object) ['test' => 1, 'test2' => 2],
      test(...),
      new stdClass(),
      'abc' => [
         1,
         'abc',
         null,
         true,
         1.2,
         (object) ['test' => 1, 'test2' => 2],
         test(...),
         new stdClass(),
         [
            1,
            'abc',
            null,
            true,
            1.2,
            (object) ['test' => 1, 'test2' => 2],
            test(...),
            new stdClass(),
            [
               1,
               'abc',
               null,
               true,
               1.2,
               (object) ['test' => 1, 'test2' => 2],
               test(...),
               new stdClass(),
               []
            ]
         ]
      ]
   ]
]);
