<?php

require __DIR__ . '/../../../../../../../autoload.php';


use Bootgly\ABI\Debugging\Data\Throwables\Errors;


class MyCustomError extends \Error
{}

function executeOperation ()
{
   Errors::report(new MyCustomError("An error occurred during operation.", 1));
}

executeOperation();
