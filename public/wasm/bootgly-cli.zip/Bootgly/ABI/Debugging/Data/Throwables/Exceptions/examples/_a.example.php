<?php

require __DIR__ . '/../../../../../../../autoload.php';


use Bootgly\ABI\Debugging\Data\Throwables\Exceptions;

function bootstrap () {
   divide(10, 0);
}

class MyCustomException extends Exception
{}

function divide ($dividend, $divisor)
{
   if ($divisor === 0) {
      throw new MyCustomException("Division by zero is not allowed.");
   }

   return $dividend / $divisor;
}

try {
   $result = bootstrap();

   echo "The result of the division is: $result";
} catch (MyCustomException $E) {
   Exceptions::report($E);
}
