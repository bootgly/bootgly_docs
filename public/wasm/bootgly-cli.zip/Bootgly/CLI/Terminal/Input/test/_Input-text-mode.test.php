<?php
/*
case INSERT_MODE = "\e[4h";
case REPLACE_MODE = "\e[4l";
case MOUSE_CLICK = "\e[M";
case RESIZE = "\e[6n";
*/
