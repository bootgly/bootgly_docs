<?php
namespace Bootgly\CLI\Terminal\Input;

// @phpstan-ignore-next-line
require '../../../../../autoload.php';


use function strlen;

use const Bootgly\CLI;


$Input = CLI->Terminal->Input;
$Output = CLI->Terminal->Output;

$Input->configure(true, false, false);


$input = '';
while ($input !== "\n") {
   $input = $Input->read(10);

   match ($input) {
      // CTRL + [key]
      Keystrokes::CTRL_A->value => $Output->write('CTRL_A'),
      Keystrokes::CTRL_B->value => $Output->write('CTRL_B'),
      #Keystrokes::CTRL_C->value => $Output->write('CTRL_C'),
      Keystrokes::CTRL_D->value => $Output->write('CTRL_D'),
      Keystrokes::CTRL_E->value => $Output->write('CTRL_E'),
      Keystrokes::CTRL_F->value => $Output->write('CTRL_F'),
      Keystrokes::CTRL_G->value => $Output->write('CTRL_G'),
      Keystrokes::CTRL_H->value => $Output->write('CTRL_H'),
      #Keystrokes::CTRL_I->value => $Output->write('CTRL_I'),
      #Keystrokes::CTRL_J->value => $Output->write('CTRL_J'),
      Keystrokes::CTRL_K->value => $Output->write('CTRL_K'),
      Keystrokes::CTRL_L->value => $Output->write('CTRL_L'),
      Keystrokes::CTRL_M->value => $Output->write('CTRL_M'),
      Keystrokes::CTRL_N->value => $Output->write('CTRL_N'),
      Keystrokes::CTRL_O->value => $Output->write('CTRL_O'),
      Keystrokes::CTRL_P->value => $Output->write('CTRL_P'),
      Keystrokes::CTRL_Q->value => $Output->write('CTRL_Q'),
      Keystrokes::CTRL_R->value => $Output->write('CTRL_R'),
      Keystrokes::CTRL_S->value => $Output->write('CTRL_S'),
      Keystrokes::CTRL_T->value => $Output->write('CTRL_T'),
      Keystrokes::CTRL_U->value => $Output->write('CTRL_U'),
      Keystrokes::CTRL_V->value => $Output->write('CTRL_V'),
      Keystrokes::CTRL_W->value => $Output->write('CTRL_W'),
      Keystrokes::CTRL_X->value => $Output->write('CTRL_X'),
      Keystrokes::CTRL_Y->value => $Output->write('CTRL_Y'),
      Keystrokes::CTRL_Z->value => $Output->write('CTRL_Z'),

      Keystrokes::CTRL_UP->value    => $Output->write('CTRL_UP'),
      Keystrokes::CTRL_DOWN->value  => $Output->write('CTRL_DOWN'),
      Keystrokes::CTRL_RIGHT->value => $Output->write('CTRL_RIGHT'),
      Keystrokes::CTRL_LEFT->value  => $Output->write('CTRL_LEFT'),

      Keystrokes::CTRL_BACKSLASH->value     => $Output->write('CTRL_BACKSLASH'),
      Keystrokes::CTRL_RIGHT_BRACKET->value => $Output->write('CTRL_RIGHT_BRACKET'),
      Keystrokes::CTRL_UNDERSCORE->value    => $Output->write('CTRL_UNDERSCORE'),
      Keystrokes::CTRL_AT->value   => $Output->write('CTRL_AT'),
      Keystrokes::CTRL_CIRCUMFLEX->value    => $Output->write('CTRL_CIRCUMFLEX'),

      // SHIFT + [key]
      Keystrokes::SHIFT_TAB->value   => $Output->write('SHIFT_TAB'),
      Keystrokes::SHIFT_UP->value    => $Output->write('SHIFT_UP'),
      Keystrokes::SHIFT_DOWN->value  => $Output->write('SHIFT_DOWN'),
      Keystrokes::SHIFT_RIGHT->value => $Output->write('SHIFT_RIGHT'),
      Keystrokes::SHIFT_LEFT->value  => $Output->write('SHIFT_LEFT'),

      // ALT + [key]
      Keystrokes::ALT_UP->value    => $Output->write('ALT_UP'),
      Keystrokes::ALT_DOWN->value  => $Output->write('ALT_DOWN'),
      Keystrokes::ALT_RIGHT->value => $Output->write('ALT_RIGHT'),
      Keystrokes::ALT_LEFT->value  => $Output->write('ALT_LEFT'),

      Keystrokes::ALT_INSERT->value    => $Output->write('ALT_INSERT'),
      Keystrokes::ALT_DELETE->value    => $Output->write('ALT_DELETE'),
      Keystrokes::ALT_HOME->value      => $Output->write('ALT_HOME'),
      Keystrokes::ALT_END->value       => $Output->write('ALT_END'),
      Keystrokes::ALT_PAGEUP->value   => $Output->write('ALT_PAGE_UP'),
      Keystrokes::ALT_PAGEDOWN->value => $Output->write('ALT_PAGE_DOWN'),

      default => null
   };
   // @phpstan-ignore-next-line
   $Output->write((string) strlen($input));
   #$Output->write($input . PHP_EOL);
   // @phpstan-ignore-next-line
   $Output->metaencode($input);
   #$Output->metaescape($input);

   $Output->write("\n");
}

$Input->configure();
