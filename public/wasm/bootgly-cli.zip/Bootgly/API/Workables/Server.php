<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Rodrigo de Araujo Vieira Tecnologia da Informação LTDA and Bootgly contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\API\Workables;


use function function_exists;
use function opcache_invalidate;
use Closure;

use Bootgly\ACI\Tests\Suite;
use Bootgly\ACI\Tests\Suite\Test\Specification;
use Bootgly\API\Environments;
use Bootgly\API\Workables\Server\Handling;
use Bootgly\API\Workables\Server\Middleware;
use Bootgly\API\Workables\Server\Middlewares;


class Server
{
   // * Config
   public static string $production = '';
   public static Environments $Environment = Environments::Production;

   // * Data
   public static Closure $Handler;
   public static Middlewares $Middlewares;
   // # Tests
   public static Suite $Suite;
   /**
    * Test Cases files
    * @var array<string,array<int|string,string>>
    */
   public static array $tests;

   // * Metadata
   private static string $key = '';
   // # Tests
   /**
    * Test Cases instances
    * @var array<string,array<int|string,Specification|Closure|null>>
    */
   public static array $Tests;

   /**
    * Index of the test whose handler is currently installed, when the
    * test harness uses index-based dispatch (`X-Bootgly-Test` header).
    * `null` means FIFO-based dispatch is in effect.
    */
   public static null|int $currentTestIndex = null;

   /**
    * Parsed value of the `X-Bootgly-Test` header stripped by
    * `Request::decode()` before exposing headers to user code. Read
    * once by `Encoder_Testing` for index-based handler dispatch.
    */
   public static null|int $testIndexHeader = null;


   public static function boot (
      bool $reset = false, string $base = '', null|string $key = null,
      null|int $testIndex = null
   ): bool
   {
      // !
      if (isSet(self::$Middlewares) === false) {
         self::$Middlewares = new Middlewares;
      }

      // * Data
      $key ??= self::$key;
      self::$key = $key;

      // @
      $bootstrap = '';
      switch (self::$Environment) {
         case Environments::Production:
            // ? No production file when handler set via handle()
            if (self::$production === '') {
               return true;
            }

            $bootstrap = self::$production;
            break;
         case Environments::Test:
            if ($base === '') {
               $bootstrap = self::$production;
               break;
            }

            // @ Index-based dispatch (order-independent):
            //   When the harness injects an `X-Bootgly-Test: N` header the
            //   Encoder passes `testIndex: N` here; we install the handler
            //   at that exact slot WITHOUT mutating the array. This breaks
            //   the FIFO coupling caused by multi-request arrays, priming
            //   side-sockets, and decode-time rejects popping extra slots.
            if (
               $testIndex !== null
               && isset(self::$Tests[$base][$testIndex])
            ) {
               $test = self::$Tests[$base][$testIndex];
               self::$currentTestIndex = $testIndex;

               if ($test instanceof Handling) {
                  self::$Handler = $test->response;

                  self::$Middlewares = new Middlewares;
                  if ($test->middlewares !== []) {
                     self::$Middlewares->pipe(...$test->middlewares);
                  }
               }

               return true;
            }

            // @ No-header fallback: a priming / side-socket request reached
            //   the encoder without `X-Bootgly-Test`. Do NOT pop the FIFO
            //   queue — priming requests must not consume slots owned by
            //   other tests. Reuse the handler already installed for the
            //   most recent indexed dispatch (or the server-wide default
            //   handler set by the first request).
            return true;
      }

      if ($reset) {
         // @ Clear Bootstrap File Cache
         if (function_exists('opcache_invalidate')) {
            opcache_invalidate($bootstrap, true);
         }

         // @ Load Bootstrap File SAPI
         $SAPI = require $bootstrap;

         $Handler = $SAPI[$key] ?? null;
         if ($Handler !== null && $Handler instanceof Closure) {
            $Handler->bindTo(null, "static"); // @phpstan-ignore-line
            self::$Handler = $Handler;
         }

         // @ Load global middlewares from SAPI
         /** @var array<Middleware> $middlewares */
         $middlewares = $SAPI['on.Middlewares'] ?? [];
         self::$Middlewares = new Middlewares;
         if ($middlewares !== []) {
            self::$Middlewares->pipe(...$middlewares);
         }
      }

      return true;
   }
}