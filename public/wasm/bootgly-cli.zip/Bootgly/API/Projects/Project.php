<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Rodrigo de Araujo Vieira Tecnologia da Informação LTDA and Bootgly contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\API\Projects;


use const DEBUG_BACKTRACE_IGNORE_ARGS;
use function basename;
use function debug_backtrace;
use function define;
use function defined;
use function dirname;
use function is_dir;
use function rtrim;
use function str_starts_with;
use function strlen;
use function substr;
use function trim;
use Closure;
use Error;

use Bootgly\ABI\Data\Language;
use Bootgly\ABI\Events\Emitter;
use Bootgly\API\Projects;
use Bootgly\API\Projects\Configs;
use Bootgly\API\Projects\Project\Events;


/**
 * Represents a Bootgly project.
 *
 * The constructor captures metadata and derives path/folder from the caller.
 * Registration (defining the BOOTGLY_PROJECT constant and adding to Projects)
 * happens only when boot() is called.
 *
 * Every project MUST declare whether it is exportable: exportable projects
 * appear in the `bootgly project create` import picker; private ones do not.
 *
 * Only one Project can be booted per process. Attempting to boot a second
 * Project throws a fatal Error.
 */
class Project
{
   // * Config
   // # Explicit
   public bool $exportable;
   public string $name;
   public string $description;
   public string $version;
   public string $author;
   // # Implicit
   public readonly string $path;
   public string $folder;

   // * Data
   public Closure $boot;
   public null|Configs $Configs = null;

   // * Metadata
   protected bool $booted = false;


   /**
    * @param Closure $boot Boot function executed by `bootgly project <Name> start` —
    *                      receives the command `$arguments` and `$options`.
    * @param bool $exportable Whether the project appears in the `bootgly project create`
    *                         import picker to be copied into user workspaces.
    * @param string $name Human-readable project name (e.g. `My App`).
    * @param string $folder Projects-root-relative folder override (e.g. `App/API`).
    *                       Derived from the signature file location when omitted.
    * @param string $description Short description shown by `bootgly project list`.
    * @param string $version Project version — plain semver (e.g. `1.0.0`).
    * @param string $author Project author (person or organization).
    */
   public function __construct (
      // * Data (required)
      Closure $boot,
      // * Config (required)
      bool $exportable,
      // * Config (optional)
      string $name = '',
      string $folder = '',
      string $description = '',
      string $version = '',
      string $author = '',
   )
   {
      // * Config
      // # Implicit
      /** @var string $callerFile */
      $callerFile = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1)[0]['file'] ?? '';
      $dir = dirname($callerFile);
      $this->path = $dir . '/';
      // @ Derive the projects-root-relative path (e.g. Demo/HTTP_Server_CLI) — the canonical id
      $base = rtrim(Projects::CONSUMER_DIR, '/');
      if (str_starts_with($dir, $base) === false) {
         $base = rtrim(Projects::AUTHOR_DIR, '/');
      }
      $relative = str_starts_with($dir, $base)
         ? trim(substr($dir, strlen($base)), '/')
         : basename($dir);
      $this->folder = $folder !== '' ? $folder : $relative;
      // # Explicit
      $this->exportable = $exportable;
      $this->name = $name;
      $this->description = $description;
      $this->version = $version;
      $this->author = $author;

      // * Data
      $this->boot = $boot;
   }

   /**
    * Boot the project.
    *
    * Defines BOOTGLY_PROJECT constant and registers in Projects on first call.
    * A second boot in the same process throws a fatal Error.
    *
    * @param array<string> $arguments
    * @param array<string, bool|int|string> $options
    */
   public function boot (array $arguments = [], array $options = []): void
   {
      // @ Register
      if ( defined('BOOTGLY_PROJECT') ) {
         throw new Error(
            'Only one Project can be booted per process. '
            . 'BOOTGLY_PROJECT is already defined.'
         );
      }

      define('BOOTGLY_PROJECT', $this);
      Projects::add($this);

      // @ Configs
      $configsDir = "{$this->path}configs/";
      if (is_dir($configsDir)) {
         $this->Configs = new Configs($configsDir);
      }

      // @ Catalogs (i18n) — convention: {project}/catalogs/{locale}/{domain}.php
      $catalogsDir = "{$this->path}catalogs";
      if (is_dir($catalogsDir)) {
         Language::load($catalogsDir);
      }

      // @
      ($this->boot)($arguments, $options);

      $this->booted = true;

      // @ Events — project booted (guarded: zero-alloc when no listeners)
      $Emitter = Emitter::$Instance;
      $Emitter->check(Events::Boot) && $Emitter->emit(Events::Boot, $this);
   }

   /**
    * Emit `Project.Shutdown` when a booted project is destroyed.
    *
    * `__destruct` timing is GC-bound; for the booted project (held by the
    * BOOTGLY_PROJECT constant + the Projects registry) this lands at process
    * teardown. A constructed-but-never-booted project never emits.
    */
   public function __destruct ()
   {
      // ?
      if ($this->booted === false) {
         return;
      }

      // @ Events — project shutting down (guarded: zero-alloc when no listeners)
      $Emitter = Emitter::$Instance;
      $Emitter->check(Events::Shutdown) && $Emitter->emit(Events::Shutdown, $this);
   }
}
