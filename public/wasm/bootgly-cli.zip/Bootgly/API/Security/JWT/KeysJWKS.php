<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright (c) 2023-present Rodrigo de Araujo Vieira Tecnologia da Informação LTDA and Bootgly contributors
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\API\Security\JWT;


use function is_array;
use InvalidArgumentException;


/**
 * Minimal RSA JSON Web Key Set parser.
 */
class KeysJWKS
{
   /**
    * Parse a JWKS document into a JWT key set.
    *
    * @param array<string,mixed> $jwks
    */
   public static function parse (array $jwks, null|string $algorithm = null): KeySet
   {
      $keys = $jwks['keys'] ?? null;
      if (is_array($keys) === false) {
         throw new InvalidArgumentException('JWKS must contain a keys array.');
      }
      if ($keys === []) {
         throw new InvalidArgumentException('JWKS must contain at least one key.');
      }

      $KeySet = new KeySet;
      /** @var array<int|string,mixed> $keys */
      foreach ($keys as $jwk) {
         if (is_array($jwk) === false) {
            throw new InvalidArgumentException('JWKS keys must be objects.');
         }

         /** @var array<string,mixed> $jwk */
         $KeySet->add(KeysJWK::parse($jwk, $algorithm));
      }

      return $KeySet;
   }
}
