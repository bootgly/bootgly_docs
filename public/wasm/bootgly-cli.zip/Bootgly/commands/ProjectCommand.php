<?php
/*
 * --------------------------------------------------------------------------
 * Bootgly PHP Framework
 * Developed by Rodrigo Vieira (@rodrigoslayertech)
 * Copyright 2023-present
 * Licensed under MIT
 * --------------------------------------------------------------------------
 */

namespace Bootgly\commands;


use const BOOTGLY_ROOT_DIR;
use const BOOTGLY_STORAGE_DIR;
use const BOOTGLY_WORKING_DIR;
use const PHP_EOL;
use const SIGKILL;
use const SIGTERM;
use const SIGUSR2;
use function array_keys;
use function array_slice;
use function basename;
use function count;
use function file_get_contents;
use function glob;
use function implode;
use function in_array;
use function intdiv;
use function is_array;
use function is_dir;
use function is_file;
use function is_numeric;
use function json_decode;
use function json_encode;
use function posix_get_last_error;
use function posix_kill;
use function readline;
use function realpath;
use function rtrim;
use function str_pad;
use function str_starts_with;
use function strlen;
use function strtolower;
use function substr;
use function time;
use function trim;
use function unlink;
use function usleep;
use Throwable;

use const Bootgly\CLI;
use Bootgly\ADI\Databases\SQL;
use Bootgly\ADI\Databases\SQL\Schema\Migrations;
use Bootgly\ADI\Databases\SQL\Schema\Runner as MigrationRunner;
use Bootgly\ADI\Databases\SQL\Seed\Runner as SeedRunner;
use Bootgly\ADI\Databases\SQL\Seed\Seeders;
use Bootgly\API\Environment\Configs\DatabaseConfig;
use Bootgly\API\Projects;
use Bootgly\API\Projects\Configs;
use Bootgly\API\Projects\Project;
use Bootgly\CLI\Command;
use Bootgly\CLI\UI\Components\Alert;
use Bootgly\CLI\UI\Components\Fieldset;


/**
 * CLI command for managing Bootgly projects.
 *
 * Provides subcommands to list, set, start, and inspect projects
 * registered in the projects/ directory (consumer or framework).
 */
class ProjectCommand extends Command
{
   // * Config
   public bool $separate = true;
   public int $group = 2;

   // * Data
   // # Command
   public string $name = 'project';
   public string $description = 'Manage Bootgly projects';
   /** @phpstan-ignore property.phpDocType */
   /** @var array<string,array<string,array<string,string>|string>> */
   public array $arguments = [ // @phpstan-ignore property.phpDocType
      'list' => [
         'description' => 'List all registered projects',
         'arguments'   => []
      ],
      'start' => [
         'description' => 'Start a project by name',
         'arguments'   => [
            '<name>' => 'Project name to start'
         ]
      ],
      'stop' => [
         'description' => 'Stop a running project',
         'arguments'   => [
            '<name>' => 'Project name to stop'
         ]
      ],
      'show' => [
         'description' => 'Show status of a running project',
         'arguments'   => [
            '<name>' => 'Project name'
         ]
      ],
      'reload' => [
         'description' => 'Hot-reload a running project',
         'arguments'   => [
            '<name>' => 'Project name to reload'
         ]
      ],
      'restart' => [
         'description' => 'Restart a running project by name',
         'arguments'   => [
            '<name>' => 'Project name to restart'
         ]
      ],
      'info' => [
         'description' => 'Show detailed info about a project',
         'arguments'   => [
            '<name>' => 'Project name'
         ]
      ],
      'migrate' => [
         'description' => 'Run project database migrations',
         'arguments'   => [
            '<name>'   => 'Project name',
            '<action>' => 'status, up, down, sync, or create',
            '[value]'  => 'Migration name for create or step count for down'
         ]
      ],
      'seed' => [
         'description' => 'Run project database seeders',
         'arguments'   => [
            '<name>'   => 'Project name',
            '<action>' => 'list, run, or create',
            '[value]'  => 'Seeder name for create or run'
         ]
      ],
   ];
   /** @var array<string,array<string>> */
   public array $options = [
      'Increase the verbosity of the command' => ['-v', '-vv', '-vvv'],
      'Preview seed run without executing SQL' => ['--dry-run'],
   ];


   /**
    * Dispatch the appropriate subcommand based on arguments.
    *
    * @param array<string> $arguments
    * @param array<string, bool|int|string> $options
    *
    * @return bool
    */
   public function run (array $arguments = [], array $options = []): bool
   {
      // @ Normalize argument order
      // Supports both: `project <subcommand> <name>` and `project <name> <subcommand>`
      $subcommands = array_keys($this->arguments);
      if (
         isSet($arguments[0], $arguments[1])
         && in_array($arguments[0], $subcommands) === false
      ) {
         if (in_array($arguments[1], $subcommands)) {
            // Swap: project <name> <subcommand> → project <subcommand> <name>
            [$arguments[0], $arguments[1]] = [$arguments[1], $arguments[0]];
         }
         else {
            // project <name> <invalid> → report the invalid subcommand, not the project name
            [$arguments[0], $arguments[1]] = [$arguments[1], $arguments[0]];
         }
      }

      return match ($arguments[0] ?? null) {
         'list'    => $this->list(),
         'start'   => $this->start(
            array_slice($arguments, 1),
            $options
         ),
         'stop'    => $this->stop(array_slice($arguments, 1)),
         'show'    => $this->show(array_slice($arguments, 1)),
         'reload'  => $this->reload(array_slice($arguments, 1)),
         'restart' => $this->restart(
            array_slice($arguments, 1),
            $options
         ),
         'info'    => $this->info(array_slice($arguments, 1)),
         'migrate' => $this->migrate(
            array_slice($arguments, 1),
            $options
         ),
         'seed'    => $this->seed(
            array_slice($arguments, 1),
            $options
         ),

         default   => $this->help($arguments)
      };
   }

   // # Subcommands
   /**
    * List all discovered projects with their interfaces and default marker.
    *
    * @return bool
    */
   public function list (): bool
   {
      $Output = CLI->Terminal->Output;

      // @ Discover per-interface metadata
      $projects_CLI = $this->discover('CLI');
      $projects_WPI = $this->discover('WPI');

      // @ Merge in registry order (kept alphabetical by path)
      /** @var array<string, array{interfaces: list<string>, name: string, description: string}> $all */
      $all = [];
      foreach (array_keys(Projects::read()) as $folder) {
         $interfaces = [];
         if (isSet($projects_CLI[$folder])) {
            $interfaces[] = 'CLI';
         }
         if (isSet($projects_WPI[$folder])) {
            $interfaces[] = 'WPI';
         }
         if ($interfaces === []) {
            continue;
         }

         $meta = $projects_CLI[$folder] ?? $projects_WPI[$folder];
         $all[$folder] = [
            'interfaces'  => $interfaces,
            'name'        => $meta['name'],
            'description' => $meta['description']
         ];
      }

      if (empty($all)) {
         $Output->render('@.;@#red: No projects found. @; @.;');
         return true;
      }

      $Output->render('@.;@#cyan: Project list: @;@..;');

      $index = 1;
      foreach ($all as $folder => $info) {
         $interfaceList = implode(', ', $info['interfaces']);

         $Output->render(
            "@#magenta: #{$index} @; - "
            . "@#yellow:{$folder}@;"
            . PHP_EOL
         );

         if ($info['description'] !== '') {
            $Output->render(
               "     @#green:Description:@; {$info['description']}" . PHP_EOL
            );
         }

         $Output->render(
            "     @#green:Type:@; {$interfaceList}@..;"
         );

         $index++;
      }

      $Output->write(PHP_EOL);

      return true;
   }

   /**
    * Start a project by loading and booting its project file.
    *
    * @param array<string> $arguments
    * @param array<string, bool|int|string> $options
    *
    * @return bool
    */
   public function start (array $arguments, array $options): bool
   {
      $Output = CLI->Terminal->Output;

      // @ Determine project name
      $projectName = $arguments[0] ?? null;

      // ? Require project name
      if ($projectName === null || $projectName === '') {
         return $this->help(['start']);
      }

      // @ Resolve project directory
      $projectDir = $this->resolve($projectName);
      if ($projectDir === null) {
         return false;
      }

      // ? Check if project is already running
      $PIDs = $this->locate($projectName);
      if ($PIDs !== null && $this->probe($PIDs['master'])) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "Project @#cyan:{$projectName}@; is already running (PID: {$PIDs['master']}). Use `project restart` instead.@.;";
         $Alert->render();

         return false;
      }

      // @ Slice out the project name from arguments for boot
      $bootArguments = $projectName === $arguments[0] // @phpstan-ignore identical.alwaysTrue
         ? array_slice($arguments, 1)
         : $arguments;

      // @ Load and boot the project file
      $projectFile = $projectDir . basename($projectName) . '.project.php';
      if (is_file($projectFile) === false) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "No project file found for @#cyan:{$projectName}@;.";
         $Alert->render();

         return false;
      }

      $Project = require $projectFile;
      if ($Project instanceof Project === false) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "Invalid project file for @#cyan:{$projectName}@;.";
         $Alert->render();

         return false;
      }

      $Project->boot($bootArguments, $options);

      return true;
   }

   /**
    * Stop a running project.
    *
    * @param array<string> $arguments
    *
    * @return bool
    */
   public function stop (array $arguments): bool
   {
      $Output = CLI->Terminal->Output;

      // ? Require project name
      $projectName = $arguments[0] ?? null;
      if ($projectName === null || $projectName === '') {
         return $this->help(['stop']);
      }

      // ? Validate project exists
      if ($this->resolve($projectName) === null) {
         return false;
      }

      // @ Collect all instances to stop
      $instances = $this->locateAll($projectName);
      if (count($instances) === 0) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "Project @#cyan:{$projectName}@; is not running.@.;";
         $Alert->render();
         return false;
      }

      $stopped = 0;
      foreach ($instances as $instance => $PIDs) {
         if ($this->probe($PIDs['master']) === false) {
            // @ Clean stale PID file
            $suffix = $instance !== '' ? '.' . $instance : '';
            $pidFile = BOOTGLY_STORAGE_DIR . 'pids/' . Projects::encode($projectName) . $suffix . '.json';
            if (is_file($pidFile)) {
               @unlink($pidFile);
            }
            continue;
         }

         $masterPid = $PIDs['master'];

         // @ Send SIGTERM to master
         if (
            posix_kill($masterPid, SIGTERM) === false
            && posix_get_last_error() === 1 // EPERM
         ) {
            $Alert = new Alert($Output);
            $Alert->Type::Failure->set();
            $Alert->message = "Project @#cyan:{$projectName}@; is running as a different user (PID {$masterPid}). Run with @#Black:sudo@; to stop it.@.;";
            $Alert->render();
            return false;
         }

         // @ Wait for graceful shutdown
         $elapsed = 0.0;
         while ($elapsed < 5.0 && $this->probe($masterPid)) {
            usleep(100000); // 100ms
            $elapsed += 0.1;
         }

         // @ Force kill if still alive
         if ($this->probe($masterPid)) {
            posix_kill($masterPid, SIGKILL);
            usleep(100000);
         }

         // @ Kill remaining workers
         foreach ($PIDs['workers'] as $workerPid) {
            if ($this->probe($workerPid)) {
               posix_kill($workerPid, SIGTERM);
            }
         }
         usleep(100000);
         foreach ($PIDs['workers'] as $workerPid) {
            if ($this->probe($workerPid)) {
               posix_kill($workerPid, SIGKILL);
            }
         }

         // @ Remove PID file
         $suffix = $instance !== '' ? '.' . $instance : '';
         $pidFile = BOOTGLY_STORAGE_DIR . 'pids/' . Projects::encode($projectName) . $suffix . '.json';
         if (is_file($pidFile)) {
            @unlink($pidFile);
         }

         $stopped++;
      }

      if ($stopped === 0) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "Project @#cyan:{$projectName}@; is not running.@.;";
         $Alert->render();
         return false;
      }

      $Alert = new Alert($Output);
      $Alert->Type::Success->set();
      $Alert->message = "Project @#cyan:{$projectName}@; stopped.@.;";
      $Alert->render();

      return true;
   }

   /**
    * Show status of a running project.
    *
    * @param array<string> $arguments
    *
    * @return bool
    */
   public function show (array $arguments): bool
   {
      $Output = CLI->Terminal->Output;

      // ? Require project name
      $projectName = $arguments[0] ?? null;
      if ($projectName === null || $projectName === '') {
         return $this->help(['show']);
      }

      // ? Validate project exists
      if ($this->resolve($projectName) === null) {
         return false;
      }

      $instances = $this->locateAll($projectName);
      if (count($instances) === 0) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "No running instance found for project @#cyan:{$projectName}@;.@.;";
         $Alert->render();

         return false;
      }

      foreach ($instances as $instance => $PIDs) {
         // @ Check master
         $masterAlive = $this->probe($PIDs['master']);
         $status = $masterAlive ? '@#green:running@;' : '@#red:stopped@;';

         // @ Count alive workers
         $workers = $PIDs['workers'];
         $aliveWorkers = 0;
         foreach ($workers as $workerPid) {
            if ($this->probe($workerPid)) {
               $aliveWorkers++;
            }
         }
         $totalWorkers = count($workers);

         // @ Calculate uptime
         $uptime = '';
         if ($masterAlive) {
            $seconds = time() - $PIDs['started'];
            $hours = intdiv($seconds, 3600);
            $minutes = intdiv($seconds % 3600, 60);
            $secs = $seconds % 60;
            $uptime = "{$hours}h {$minutes}m {$secs}s";
         }

         // @ Build Fieldset content
         $displayName = $instance !== '' ? $projectName . '.' . $instance : $projectName;

         $content = '';
         $content .= '@#Green:' . str_pad('Project', 14) . ' @; ' . $displayName . PHP_EOL;
         $content .= '@#Green:' . str_pad('Type', 14) . ' @; ' . $PIDs['type'] . PHP_EOL;
         $content .= '@#Green:' . str_pad('Status', 14) . ' @; ' . $status . PHP_EOL;
         $content .= '@#Green:' . str_pad('Master PID', 14) . ' @; ' . $PIDs['master'] . PHP_EOL;

         if ($PIDs['type'] === 'WPI' || $PIDs['type'] === 'WPI-Client') {
            $content .= '@#Green:' . str_pad('Workers', 14) . ' @; ' . $aliveWorkers . '/' . $totalWorkers . PHP_EOL;
         }

         if ($PIDs['type'] === 'WPI') {
            $content .= '@#Green:' . str_pad('Address', 14) . ' @; ' . $PIDs['host'] . ':' . $PIDs['port'] . PHP_EOL;
         }

         if ($uptime !== '') {
            $content .= '@#Green:' . str_pad('Uptime', 14) . ' @; ' . $uptime;
         }

         $content = rtrim($content);

         $Output->write(PHP_EOL);
         $Fieldset = new Fieldset($Output);
         $Fieldset->title = '@#Cyan: Project Status @;';
         $Fieldset->content = $content;
         $Fieldset->render();
      }

      return true;
   }

   /**
    * Hot-reload a running project.
    *
    * @param array<string> $arguments
    *
    * @return bool
    */
   public function reload (array $arguments): bool
   {
      $Output = CLI->Terminal->Output;

      // ? Require project name
      $projectName = $arguments[0] ?? null;
      if ($projectName === null || $projectName === '') {
         return $this->help(['reload']);
      }

      // ? Validate project exists
      if ($this->resolve($projectName) === null) {
         return false;
      }

      $PIDs = $this->locate($projectName);
      if ($PIDs === null || $this->probe($PIDs['master']) === false) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "Project @#cyan:{$projectName}@; is not running.@.;";
         $Alert->render();

         return false;
      }

      // @ Send SIGUSR2 to master
      posix_kill($PIDs['master'], SIGUSR2);

      $Alert = new Alert($Output);
      $Alert->Type::Success->set();
      $Alert->message = "Reload signal sent to project @#cyan:{$projectName}@;.@.;";
      $Alert->render();

      return true;
   }

   /**
    * Restart a running project (stop then start).
    *
    * @param array<string> $arguments
    * @param array<string, bool|int|string> $options
    *
    * @return bool
    */
   public function restart (array $arguments, array $options): bool
   {
      $Output = CLI->Terminal->Output;

      // ? Require project name
      $projectName = $arguments[0] ?? null;
      if ($projectName === null || $projectName === '') {
         return $this->help(['restart']);
      }

      // ? Validate project exists
      if ($this->resolve($projectName) === null) {
         return false;
      }

      // @ Stop if running
      $PIDs = $this->locate($projectName);
      if ($PIDs !== null && $this->probe($PIDs['master'])) {
         $Output->render('@.;@#yellow:Stopping project...@;@.;');
         $this->stop($arguments);
      }

      // @ Start
      return $this->start($arguments, $options);
   }

   /**
    * Run project database migrations.
    *
    * @param array<string> $arguments
    * @param array<string, bool|int|string> $options
    *
    * @return bool
    */
   public function migrate (array $arguments, array $options): bool
   {
      $Output = CLI->Terminal->Output;

      $projectName = $arguments[0] ?? null;
      if ($projectName === null || $projectName === '') {
         return $this->help(['migrate']);
      }

      $projectDir = $this->resolve($projectName);
      if ($projectDir === null) {
         return false;
      }

      $action = $arguments[1] ?? 'status';
      $migrationsPath = $projectDir . 'database/migrations';

      if ($action === 'create') {
         $name = $arguments[2] ?? null;
         if ($name === null || $name === '') {
            return $this->help(['migrate']);
         }

         $Migrations = new Migrations($migrationsPath);
         $file = $Migrations->create($name);

         $Alert = new Alert($Output);
         $Alert->Type::Success->set();
         $Alert->message = "Migration created: @#cyan:{$file}@;@.;";
         $Alert->render();

         return true;
      }

      $Project = $this->open($projectName);
      if ($Project === null) {
         return false;
      }

      $Database = $this->configure($Project);
      if ($Database === null) {
         return false;
      }

      $lockFile = BOOTGLY_STORAGE_DIR . 'locks/migrations/' . Projects::encode($projectName) . '.lock';
      $Runner = new MigrationRunner($Database, $migrationsPath, $lockFile);

      try {
         if ($action === 'status') {
            $Status = $Runner->report();

            $content = '';
            $content .= '@#Green:' . str_pad('Applied', 12) . ' @; ' . count($Status['applied']) . PHP_EOL;
            $content .= '@#Green:' . str_pad('Local only', 12) . ' @; ' . count($Status['pending']) . PHP_EOL;
            $content .= '@#Green:' . str_pad('DB only', 12) . ' @; ' . count($Status['missing']);

            if ($Status['pending'] !== []) {
               $content .= PHP_EOL . '@#Green:' . str_pad('Next', 12) . ' @; ' . $Status['pending'][0];
            }

            if ($Status['missing'] !== []) {
               $content .= PHP_EOL . '@#Green:' . str_pad('Remove', 12) . ' @; ' . $Status['missing'][0];
            }

            $Output->write(PHP_EOL);
            $Fieldset = new Fieldset($Output);
            $Fieldset->title = '@#Cyan: Migration Status @;';
            $Fieldset->content = $content;
            $Fieldset->render();
            $Output->write(PHP_EOL);

            return true;
         }

         if ($action === 'sync') {
            $Status = $Runner->report();

            $content = '';
            $content .= '@#Green:' . str_pad('Applied', 12) . ' @; ' . count($Status['applied']) . PHP_EOL;
            $content .= '@#Green:' . str_pad('Add', 12) . ' @; ' . count($Status['pending']) . PHP_EOL;
            $content .= '@#Green:' . str_pad('Delete', 12) . ' @; ' . count($Status['missing']);

            if ($Status['pending'] !== []) {
               $content .= PHP_EOL . '@#Green:' . str_pad('Add first', 12) . ' @; ' . $Status['pending'][0];
            }

            if ($Status['missing'] !== []) {
               $content .= PHP_EOL . '@#Green:' . str_pad('Delete first', 12) . ' @; ' . $Status['missing'][0];
            }

            $Output->write(PHP_EOL);
            $Fieldset = new Fieldset($Output);
            $Fieldset->title = '@#Cyan: Migration Sync Check @;';
            $Fieldset->content = $content;
            $Fieldset->render();
            $Output->write(PHP_EOL);

            if ($Status['pending'] === [] && $Status['missing'] === []) {
               $Alert = new Alert($Output);
               $Alert->Type::Success->set();
               $Alert->message = 'Migration history is already synchronized.@.;';
               $Alert->render();

               return true;
            }

            if ($this->confirm("Apply migration sync to {$Runner->Repository->table}? [y/N]") === false) {
               $Alert = new Alert($Output);
               $Alert->Type::Attention->set();
               $Alert->message = 'Migration sync cancelled.@.;';
               $Alert->render();

               return true;
            }

            $Sync = $Runner->sync();

            $content = '';
            $content .= '@#Green:' . str_pad('Added', 12) . ' @; ' . count($Sync['added']) . PHP_EOL;
            $content .= '@#Green:' . str_pad('Deleted', 12) . ' @; ' . count($Sync['deleted']);

            $Output->write(PHP_EOL);
            $Fieldset = new Fieldset($Output);
            $Fieldset->title = '@#Cyan: Migration Sync Applied @;';
            $Fieldset->content = $content;
            $Fieldset->render();
            $Output->write(PHP_EOL);

            return true;
         }

         if ($action === 'up') {
            $limit = isset($arguments[2]) && is_numeric($arguments[2]) ? (int) $arguments[2] : 0;
            $applied = $Runner->up($limit);

            $Alert = new Alert($Output);
            $Alert->Type::Success->set();
            $Alert->message = 'Migrations applied: @#cyan:' . count($applied) . '@;@.;';
            $Alert->render();

            return true;
         }

         if ($action === 'down') {
            if (isset($arguments[2]) === false || is_numeric($arguments[2]) === false) {
               $Alert = new Alert($Output);
               $Alert->Type::Failure->set();
               $Alert->message = 'Migration down requires a numeric step count.@.;';
               $Alert->render();

               return false;
            }

            $reverted = $Runner->down((int) $arguments[2]);

            $Alert = new Alert($Output);
            $Alert->Type::Success->set();
            $Alert->message = 'Migrations reverted: @#cyan:' . count($reverted) . '@;@.;';
            $Alert->render();

            return true;
         }
      }
      catch (Throwable $Throwable) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = $Throwable->getMessage() . '@.;';
         $Alert->render();

         return false;
      }

      $Alert = new Alert($Output);
      $Alert->Type::Failure->set();
      $Alert->message = "Invalid migration action: @#cyan:{$action}@;@.;";
      $Alert->render();

      return false;
   }

   /**
    * Run project database seeders.
    *
    * @param array<string> $arguments
    * @param array<string, bool|int|string> $options
    *
    * @return bool
    */
   public function seed (array $arguments, array $options): bool
   {
      $Output = CLI->Terminal->Output;

      $projectName = $arguments[0] ?? null;
      if ($projectName === null || $projectName === '') {
         return $this->help(['seed']);
      }

      $projectDir = $this->resolve($projectName);
      if ($projectDir === null) {
         return false;
      }

      $action = $arguments[1] ?? 'list';
      $seedersPath = "{$projectDir}database/seeders";
      $Seeders = new Seeders($seedersPath);

      try {
         if ($action === 'create') {
            $name = $arguments[2] ?? null;
            if ($name === null || $name === '') {
               return $this->help(['seed']);
            }

            $file = $Seeders->create($name);

            $Alert = new Alert($Output);
            $Alert->Type::Success->set();
            $Alert->message = "Seeder created: @#cyan:{$file}@;@.;";
            $Alert->render();

            return true;
         }

         if ($action === 'list') {
            $files = $Seeders->discover();

            $content = '';
            $content .= '@#Green:' . str_pad('Count', 12) . ' @; ' . count($files);

            foreach (array_keys($files) as $name) {
               $content .= PHP_EOL . '@#Green:' . str_pad('Seeder', 12) . ' @; ' . $name;
            }

            $Output->write(PHP_EOL);
            $Fieldset = new Fieldset($Output);
            $Fieldset->title = '@#Cyan: Seeder List @;';
            $Fieldset->content = $content;
            $Fieldset->render();
            $Output->write(PHP_EOL);

            return true;
         }

         if ($action === 'run') {
            $Project = $this->open($projectName);
            if ($Project === null) {
               return false;
            }

            $Database = $this->configure($Project);
            if ($Database === null) {
               return false;
            }

            $lockFile = BOOTGLY_STORAGE_DIR . 'locks/seeders/' . Projects::encode($projectName) . '.lock';
            $Runner = new SeedRunner($Database, $seedersPath, $lockFile);
            $name = $arguments[2] ?? null;

            if (isset($options['dry-run'])) {
               $Preview = $Runner->preview($name === '' ? null : $name);

               $content = '';
               $content .= '@#Green:' . str_pad('Seeders', 12) . ' @; ' . count($Preview);

               foreach ($Preview as $seeder => $queries) {
                  $content .= PHP_EOL . '@#Green:' . str_pad('Seeder', 12) . " @; {$seeder}";

                  if ($queries === []) {
                     $content .= PHP_EOL . '@#Green:' . str_pad('SQL', 12) . ' @; (none)';
                     continue;
                  }

                  foreach ($queries as $index => $query) {
                     $number = $index + 1;
                     $content .= PHP_EOL . '@#Green:' . str_pad("SQL {$number}", 12) . " @; {$query['sql']}";

                     if ($query['parameters'] !== []) {
                        $parameters = json_encode($query['parameters']) ?: '[]';
                        $content .= PHP_EOL . '@#Green:' . str_pad('Parameters', 12) . " @; {$parameters}";
                     }
                  }
               }

               $Output->write(PHP_EOL);
               $Fieldset = new Fieldset($Output);
               $Fieldset->title = '@#Cyan: Seeder Dry Run @;';
               $Fieldset->content = $content;
               $Fieldset->render();
               $Output->write(PHP_EOL);

               $Alert = new Alert($Output);
               $Alert->Type::Attention->set();
               $Alert->message = 'Dry run only; no seeder SQL was executed.@.;';
               $Alert->render();

               return true;
            }

            $ran = $Runner->run($name === '' ? null : $name);

            $Alert = new Alert($Output);
            $Alert->Type::Success->set();
            $Alert->message = 'Seeders run: @#cyan:' . count($ran) . '@;@.;';
            $Alert->render();

            return true;
         }
      }
      catch (Throwable $Throwable) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = $Throwable->getMessage() . '@.;';
         $Alert->render();

         return false;
      }

      $Alert = new Alert($Output);
      $Alert->Type::Failure->set();
      $Alert->message = "Invalid seeder action: @#cyan:{$action}@;@.;";
      $Alert->render();

      return false;
   }

   // @ Helpers
   /**
    * Confirm one destructive CLI action.
    */
   private function confirm (string $question): bool
   {
      $answer = readline($question . ' ');
      if ($answer === false) {
         return false;
      }

      return in_array(strtolower(trim($answer)), ['y', 'yes'], true);
   }

   /**
    * Open one project file without booting it.
    */
   private function open (string $projectName): null|Project
   {
      $Output = CLI->Terminal->Output;
      $projectDir = $this->resolve($projectName);
      if ($projectDir === null) {
         return null;
      }

      $projectFile = $projectDir . basename($projectName) . '.project.php';
      if (is_file($projectFile) === false) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "No project file found for @#cyan:{$projectName}@;.";
         $Alert->render();

         return null;
      }

      $Project = require $projectFile;
      if ($Project instanceof Project === false) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "Invalid project file for @#cyan:{$projectName}@;.";
         $Alert->render();

         return null;
      }

      return $Project;
   }

   /**
    * Configure the project database facade from the database config scope.
    */
   private function configure (Project $Project): null|SQL
   {
      $Output = CLI->Terminal->Output;
      $configsDir = $Project->path . 'configs/';

      if (is_dir($configsDir) === false) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "Project has no configs directory: @#cyan:{$Project->folder}@;@.;";
         $Alert->render();

         return null;
      }

      $Configs = new Configs($configsDir);
      if ($Configs->load('database') === false) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "Project has no database config scope: @#cyan:{$Project->folder}@;@.;";
         $Alert->render();

         return null;
      }

      $Scope = $Configs->Scopes->get('database');
      if ($Scope === null) {
         return null;
      }

      $Config = new DatabaseConfig($Scope)->configure();

      return new SQL($Config);
   }

   /**
    * Resolve the project directory path.
    *
    * @param string $projectName
    *
    * @return null|string The resolved directory path, or null if not found.
    */
   private function resolve (string $projectName): null|string
   {
      $Output = CLI->Terminal->Output;

      // ? Security gate: path-safety + allow-list membership
      if (Projects::validate($projectName) === false) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "Project not registered: @#cyan:{$projectName}@;@.;";
         $Alert->render();

         $Output->render(
            '@#Green:Tip:@; Register it in @#Black:projects/Bootgly.projects.php@; or use @#Black:bootgly project list@;.@..;'
         );

         return null;
      }

      // @ Resolve dir (consumer dir wins, framework fallback)
      $projectsBase = BOOTGLY_WORKING_DIR . 'projects/';
      $projectDir = $projectsBase . $projectName . '/';
      if (is_dir($projectDir) === false) {
         $projectsBase = BOOTGLY_ROOT_DIR . 'projects/';
         $projectDir = $projectsBase . $projectName . '/';
      }
      if (is_dir($projectDir) === false) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "Project not found: @#cyan:{$projectName}@;@.;";
         $Alert->render();

         $Output->render(
            '@#Green:Tip:@; Use @#Black:bootgly project list@; to see all available projects.@..;'
         );

         return null;
      }

      // ? Defense-in-depth: jail the resolved dir under the projects base
      $real = realpath($projectDir);
      $realBase = realpath($projectsBase);
      if ($real === false || $realBase === false || str_starts_with($real, $realBase . '/') === false) {
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "Project path escapes the projects directory: @#cyan:{$projectName}@;@.;";
         $Alert->render();

         return null;
      }

      // :
      return $projectDir;
   }

   /**
    * Locate a running project's PID data from its state file.
    *
    * @param string $projectName
    * @param null|string $instance Optional instance qualifier (e.g. 'test').
    *
    * @return null|array{master: int, workers: array<int>, host: string, port: int, started: int, type: string}
    */
   private function locate (string $projectName, null|string $instance = null): null|array
   {
      $suffix = $instance !== null ? '.' . $instance : '';
      $pidFile = BOOTGLY_STORAGE_DIR . 'pids/' . Projects::encode($projectName) . $suffix . '.json';

      if (is_file($pidFile) === false) {
         return null;
      }

      $content = file_get_contents($pidFile);
      if ($content === false) {
         return null;
      }

      /** @var null|array{master: int, workers: array<int>, host: string, port: int, started: int, type: string} $data */
      $data = json_decode($content, true);

      if (is_array($data) === false || isSet($data['master']) === false) { // @phpstan-ignore isset.offset, identical.alwaysFalse
         return null;
      }

      return $data;
   }

   /**
    * List all running instances for a project.
    *
    * @param string $projectName
    *
    * @return array<string, array{master: int, workers: array<int>, host: string, port: int, started: int, type: string}>
    *         Keys are instance names ('' for primary, 'test' for test, etc.)
    */
   private function locateAll (string $projectName): array
   {
      $pidsDir = BOOTGLY_STORAGE_DIR . 'pids/';
      $instances = [];

      // @ Primary instance
      $primary = $this->locate($projectName);
      if ($primary !== null) {
         $instances[''] = $primary;
      }

      // @ Named instances (e.g. Demo~HTTP_Server_CLI.test.json)
      $encoded = Projects::encode($projectName);
      $pattern = $pidsDir . $encoded . '.*.json';
      $files = glob($pattern);
      if ($files !== false) {
         foreach ($files as $file) {
            $basename = basename($file, '.json'); // Demo~HTTP_Server_CLI.test
            $instance = substr($basename, strlen($encoded) + 1); // test
            $data = $this->locate($projectName, $instance);
            if ($data !== null) {
               $instances[$instance] = $data;
            }
         }
      }

      return $instances;
   }

   /**
    * Probe if a process is alive.
    *
    * Uses `/proc/<pid>` when available (Linux) so we detect processes owned
    * by other users (e.g. a server demoted to www-data probed by the caller
    * as rodrigo — `posix_kill($pid, 0)` returns false with EPERM in that
    * case, which would otherwise be misread as "process not running").
    *
    * @param int $pid
    *
    * @return bool
    */
   private function probe (int $pid): bool
   {
      if ($pid <= 0) {
         return false;
      }

      if (is_dir('/proc/' . $pid)) {
         return true;
      }

      if (posix_kill($pid, 0)) {
         return true;
      }

      return posix_get_last_error() === 1; // EPERM → process exists, not ours
   }

   /**
    * Discover projects for a given interface type.
    *
    * @param string $interface CLI or WPI
    *
    * @return array<string, array{name: string, description: string, version: string, author: string}>
    */
   private function discover (string $interface): array
   {
      // !
      $projects = [];

      // @ Try consumer dir first, then framework dir
      $projectsDir = is_dir(BOOTGLY_WORKING_DIR . 'projects')
         ? BOOTGLY_WORKING_DIR . 'projects/'
         : BOOTGLY_ROOT_DIR . 'projects/';

      // @ Iterate the registered paths for this interface (leaf-named project files)
      foreach (Projects::filter($interface) as $path) {
         $leaf = basename($path);
         $file = $projectsDir . $path . '/' . $leaf . '.project.php';
         if (is_file($file)) {
            $projects[$path] = $this->get($file, $path);
         }
      }

      // :
      return $projects;
   }

   /**
    * Get project metadata from project file.
    *
    * @param string $file The project file path
    * @param string $folder The project folder name (fallback)
    *
    * @return array{name: string, description: string, version: string, author: string}
    */
   private function get (string $file, string $folder): array
   {
      // !
      $defaults = [
         'name'        => $folder,
         'description' => '',
         'version'     => '',
         'author'      => ''
      ];

      // @
      $Project = require $file;
      if ($Project instanceof Project === false) {
         return $defaults;
      }

      // :
      return [
         'name'        => $Project->name !== '' ? $Project->name : $folder,
         'description' => $Project->description,
         'version'     => $Project->version,
         'author'      => $Project->author
      ];
   }

   /**
    * Show detailed information about a specific project.
    *
    * @param array<string> $arguments
    *
    * @return bool
    */
   public function info (array $arguments): bool
   {
      $Output = CLI->Terminal->Output;

      // ? Require project name
      $folder = $arguments[0] ?? null;
      if ($folder === null || $folder === '') {
         return $this->help(['info']);
      }

      // @ Resolve project directory
      $projectDir = $this->resolve($folder);
      if ($projectDir === null) {
         return false;
      }

      // @ Load metadata from project file (leaf-named)
      $projectFile = $projectDir . basename($folder) . '.project.php';
      $meta = is_file($projectFile)
         ? $this->get($projectFile, $folder)
         : ['name' => $folder, 'description' => '', 'version' => '', 'author' => ''];

      // @ Detect interfaces from index files
      $interfaces = [];
      $projects_CLI = $this->discover('CLI');
      $projects_WPI = $this->discover('WPI');
      if (isSet($projects_CLI[$folder])) {
         $interfaces[] = 'CLI';
      }
      if (isSet($projects_WPI[$folder])) {
         $interfaces[] = 'WPI';
      }

      // @ Build Fieldset content
      $content = '';
      $content .= '@#Green:' . str_pad('Name', 14) . ' @; ' . $meta['name'] . PHP_EOL;
      $content .= '@#Green:' . str_pad('Folder', 14) . ' @; ' . $folder . PHP_EOL;
      $content .= '@#Green:' . str_pad('Description', 14) . ' @; ' . ($meta['description'] ?: '(none)') . PHP_EOL;
      $content .= '@#Green:' . str_pad('Version', 14) . ' @; ' . ($meta['version'] ?: '(none)') . PHP_EOL;
      $content .= '@#Green:' . str_pad('Author', 14) . ' @; ' . ($meta['author'] ?: '(none)') . PHP_EOL;
      $content .= '@#Green:' . str_pad('Interfaces', 14) . ' @; ' . (implode(', ', $interfaces) ?: '(none)') . PHP_EOL;
      $content .= '@#Green:' . str_pad('Path', 14) . ' @; ' . $projectDir;

      $Output->write(PHP_EOL);
      $Fieldset = new Fieldset($Output);
      $Fieldset->title = '@#Cyan: Project Info @;';
      $Fieldset->content = $content;
      $Fieldset->render();
      $Output->write(PHP_EOL);

      return true;
   }

   // ...
   /**
    * Display usage help or report invalid arguments.
    *
    * @param array<string> $arguments
    *
    * @return bool
    */
   public function help (array $arguments): bool
   {
      $Output = CLI->Terminal->Output;

      // @
      $output = '';
      $status = true;

      if ( empty($arguments) ) {
         $Output->write(PHP_EOL);

         // # Arguments
         $content = '';
         foreach ($this->arguments as $name => $value) {
            /** @var array{description: string, arguments: array<string,string>}|string $value */
            $description = is_array($value) ? $value['description'] : $value;
            $label = $name;
            $content .= '@#Yellow:' . $name . '@;';
            $content .= str_pad('', 10 - strlen($label)) . '  ' . $description . PHP_EOL;
         }
         $content = rtrim($content);
         $Fieldset = new Fieldset($Output);
         $Fieldset->title = '@#Cyan: Project arguments @;';
         $Fieldset->content = $content;
         $Fieldset->render();

         // # Usage
         $Fieldset = new Fieldset($Output);
         $Fieldset->title = '@#green: Project usage @;';
         $Fieldset->content = 'bootgly project @#Black: <argument> @;@.;';
         $Fieldset->content .= 'bootgly project @#Black: <argument> <name> @;@.;';
         $Fieldset->content .= 'bootgly project @#Black: <name> <argument> @;';
         $Fieldset->render();

         // # Examples
         $exampleLines = '@#Black:bootgly project list@;' . PHP_EOL;
         $exampleLines .= '@#Black:bootgly project Demo/HTTP_Server_CLI start@;' . PHP_EOL;
         $exampleLines .= '@#Black:bootgly project Demo/HTTP_Server_CLI stop@;' . PHP_EOL;
         $exampleLines .= '@#Black:bootgly project Demo/HTTP_Server_CLI show@;' . PHP_EOL;
         $exampleLines .= '@#Black:bootgly project Demo/HTTP_Server_CLI restart@;' . PHP_EOL;
         $exampleLines .= '@#Black:bootgly project Demo/HTTP_Server_CLI info@;' . PHP_EOL;
         $exampleLines .= PHP_EOL;
         $exampleLines .= '@#Black:bootgly project start Demo/HTTP_Server_CLI@;' . PHP_EOL;
         $exampleLines .= '@#Black:bootgly project stop Demo/HTTP_Server_CLI@;' . PHP_EOL;
         $exampleLines .= '@#Black:bootgly project show Demo/HTTP_Server_CLI@;';
         $Fieldset = new Fieldset($Output);
         $Fieldset->title = '@#green: Project examples @;';
         $Fieldset->content = $exampleLines;
         $Fieldset->render();
      }
      else if ( isSet($this->arguments[$arguments[0]]) ) {
         $status = false;

         // @ Show usage for a valid subcommand
         $subcommand = $arguments[0];
         /** @var array{description: string, arguments: array<string,string>} $meta */
         $meta = $this->arguments[$subcommand];

         $Output->write(PHP_EOL);
         $Output->render("@#Black: {$meta['description']}@;@.;");

         // @ Alert missing <name>
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = 'Missing required argument: @#cyan:<name>@;';
         $Alert->render();
         $Output->write(PHP_EOL);

         // @ Show arguments if any
         if ( !empty($meta['arguments']) ) {
            $argLines = '';
            foreach ($meta['arguments'] as $arg => $argDesc) {
               $argLines .= '@#cyan:' . str_pad($arg, 9) . '@; ' . $argDesc . PHP_EOL;
            }
            $argLines = rtrim($argLines);

            $Fieldset = new Fieldset($Output);
            $Fieldset->title = '@#Cyan: Project ' . $subcommand . ' arguments @;';
            $Fieldset->content = $argLines;
            $Fieldset->render();
         }

         // # Usage
         $Fieldset = new Fieldset($Output);
         $Fieldset->title = '@#Cyan: Project ' . $subcommand . ' usage @;';
         $Fieldset->content = 'bootgly project ' . $subcommand . ' @#Black: <name> @;' . PHP_EOL
            . 'bootgly project @#Black: <name>  @;' . $subcommand;
         $Fieldset->render();

         // # Example
         $Fieldset = new Fieldset($Output);
         $Fieldset->title = '@#Cyan: Project ' . $subcommand . ' example @;';
         $Fieldset->content = '@#Black:bootgly project Demo/HTTP_Server_CLI ' . $subcommand . '@;' . PHP_EOL
            . '@#Black:bootgly project ' . $subcommand . ' Demo/HTTP_Server_CLI@;';
         $Fieldset->render();

         // # Hint
         $Output->render(
            '@.;@#Green:Tip:@; Use @#Black:bootgly project list@; to see all available projects.@.;'
         );
      }
      else {
         $status = false;

         // @ Show invalid argument alert then general help
         $Alert = new Alert($Output);
         $Alert->Type::Failure->set();
         $Alert->message = "Invalid argument: @#cyan:{$arguments[0]}@;.";
         $Alert->render();

         $this->help([]);

         return false;
      }

      $output .= '@.;';

      $Output->render($output);

      return $status;
   }
}
